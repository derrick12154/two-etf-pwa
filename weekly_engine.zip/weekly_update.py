"""Fetch complete ETF weeks, audit the fixed strategy and publish an encrypted snapshot.

Run from the extracted weekly_engine.zip; APP_PASSWORD is supplied only through env.
No prices, plaintext signals or credentials are written into the published artifact.
"""
import argparse
import hashlib
import io
import json
import os
import shutil
import uuid
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd

import etf_universe as source
import weekly_momentum as base
from volatility_research import simulate, audit, volatility_panel, risk_weight, rebalance_gate
from buffer_research import annual_drawdown
from strategy import metrics
from sealed_data import unseal, write_sealed

SYMBOLS = ['sz159915', 'sh513100']
CALENDAR_SYMBOL = 'sh510300'
NAMES = {'sz159915': '创业板ETF', 'sh513100': '纳斯达克100ETF', 'CASH': '现金'}
CALENDAR_URL = 'https://finance.sina.com.cn/realstock/company/klc_td_sh.txt'


def fetch_calendar():
    response = source.public_get(CALENDAR_URL, {}, 'price')
    encoded = json.JSONDecoder().raw_decode(response.text.split('=', 1)[1].lstrip())[0]
    rows = source.decode_sina(encoded)
    dates = pd.DatetimeIndex(pd.to_datetime(rows, utc=True)).tz_localize(None).normalize()
    dates = dates.unique().sort_values()
    if len(dates) < 5000 or (dates.weekday >= 5).any():
        raise ValueError('Invalid exchange calendar')
    return dates, hashlib.sha256(response.content).hexdigest()


def complete_week(calendar, as_of):
    """Return latest fully elapsed nonempty exchange week and its next trading open."""
    as_of = pd.Timestamp(as_of)
    friday = as_of.to_period('W-FRI').end_time.normalize()
    if calendar[-1] < friday + pd.Timedelta(days=7):
        raise ValueError('Trading calendar does not cover the next week; refresh source first')
    ends = pd.Series(calendar, index=calendar).groupby(calendar.to_period('W-FRI')).last()
    elapsed = ends.loc[ends <= as_of]
    if elapsed.empty:
        raise ValueError('No completed market week')
    end = pd.Timestamp(elapsed.iloc[-1])
    upcoming = calendar[calendar > end]
    return end, pd.Timestamp(upcoming[0])


def check_recent_prices(frames, calendar, end, anchor):
    expected = calendar[(calendar > pd.Timestamp(anchor)) & (calendar <= end)]
    for symbol, frame in frames.items():
        if frame.index[-1] != end:
            raise ValueError(f'{symbol}: quotes lag the completed week; refusing stale publication')
        if len(expected.difference(frame.index)):
            raise ValueError(f'{symbol}: unconfirmed missing bars after the accepted baseline')
        extra = frame.index[frame.index > pd.Timestamp(anchor)].difference(expected)
        if len(extra):
            raise ValueError(f'{symbol}: non-session bars returned by source')


def fetch_snapshot(seed, directory, calendar, end):
    source.DATA = directory
    records, frames, hashes = [], {}, {}
    for symbol in SYMBOLS + [CALENDAR_SYMBOL]:
        meta = source.fetch_sina_prices({'symbol': symbol}, str(end.date()))
        path = directory/'prices'/f'{symbol}.csv'
        frame = pd.read_csv(path, parse_dates=['date']).set_index('date')
        accepted = pd.read_csv(io.StringIO(seed['prices'][symbol]), parse_dates=['date']).set_index('date')
        common = accepted.index.intersection(frame.index)
        if not accepted.index.isin(frame.index).all():
            raise ValueError(f'{symbol}: source removed accepted historical bars')
        # Adjustment revisions need review; do not silently rewrite accepted history.
        np.testing.assert_allclose(frame.loc[common, ['open','close','high','low']],
                                   accepted.loc[common, ['open','close','high','low']], rtol=1e-8, atol=1e-8)
        frames[symbol] = frame
        hashes[symbol] = meta['sha256']
        if symbol in SYMBOLS:
            records.append(dict(code=symbol[2:], symbol=symbol, **{k:v for k,v in meta.items() if k!='symbol'}))
    check_recent_prices(frames, calendar, end, seed['anchor'])
    pd.DataFrame(records).to_csv(directory/'universe.csv', index=False)
    accepted_scale = pd.read_csv(io.StringIO(seed['scaleHistory']), parse_dates=['report_date'])
    scales = []
    expected_report = (end - pd.Timedelta(days=100)).to_period('Q').start_time - pd.Timedelta(days=1)
    for symbol in SYMBOLS:
        current = source.fetch_scale({'code': symbol[2:], 'symbol': symbol})
        if current.report_date.max() < expected_report:
            raise ValueError(f'{symbol}: latest historically-available quarterly scale is missing')
        old = accepted_scale.loc[accepted_scale.symbol.eq(symbol)]
        # Keep accepted history immutable; append reports that were unavailable at the anchor.
        scales.append(pd.concat([old, current.loc[current.report_date > old.report_date.max()]], ignore_index=True))
    scale = pd.concat(scales, ignore_index=True).sort_values(['symbol','report_date'])
    scale.to_csv(directory/'scale_history.csv', index=False, date_format='%Y-%m-%d')
    crosscheck = crosscheck_prices(frames,end)
    manifest = dict(provider='Sina ETF bars and affine historical adjustment factors',
                    downloadedAt=datetime.now(ZoneInfo('UTC')).isoformat(), requestedEnd=str(end.date()),
                    calendarSha256=hashlib.sha256('|'.join(map(str,calendar)).encode()).hexdigest(),
                    benchmark_sha256=hashes[CALENDAR_SYMBOL], hashes=hashes,priceCrosscheck=crosscheck)
    (directory/'manifest.json').write_text(json.dumps(manifest), encoding='utf8')
    return manifest


def crosscheck_prices(frames,end):
    """Independent recent price-shape check; providers may use different HFQ bases."""
    result={}
    for symbol in SYMBOLS:
        reference=frames[symbol].tail(20)
        parameter=f'{symbol},day,{reference.index[0].date()},{end.date()},640,hfq'
        response=source.public_get('https://web.ifzq.gtimg.cn/appstock/app/fqkline/get',{'param':parameter},'price')
        block=response.json().get('data',{}).get(symbol,{})
        rows=block.get('hfqday')
        if not rows: raise ValueError(f'{symbol}: independent adjusted quotes unavailable')
        other=pd.DataFrame([row[:6] for row in rows],columns=['date','open','close','high','low','volume'])
        other['date']=pd.to_datetime(other.date)
        other=other.set_index('date').astype(float)
        if not reference.index.isin(other.index).all():
            raise ValueError(f'{symbol}: independent quotes lag or contain gaps')
        other=other.loc[reference.index]
        # Calibrate only on the earlier half; newest quotes cannot calibrate their own check.
        ratio=float((reference.close.iloc[:10]/other.close.iloc[:10]).median())
        fields=['open','close','high','low']
        error=float(((other[fields]*ratio-reference[fields])/reference[fields]).abs().to_numpy().max())
        if error>0.001:
            raise ValueError(f'{symbol}: independent recent OHLC differ materially ({error:.4%})')
        result[symbol]=dict(passed=True,bars=len(reference),maxNormalizedRelativeError=error,
                            tolerance=.001,provider='Tencent hfq; constant base normalized from earlier bars')
    return result


def next_signal(panel, cfg, daily, vol, execution):
    date = panel['close'].index[-1]
    closes = panel['weekly_close']
    assert closes.index[-1] == date
    scheduled = len(daily.index.to_period('W-FRI').unique()) % cfg['rebalance_every_weeks'] == 0
    mom, assets = panel['momentum'].loc[date], panel['assets'].loc[date]
    observed = panel['signal_observed'].loc[date] & panel['trend_pass'].loc[date]
    eligible = mom.notna() & mom.gt(0) & assets.gt(cfg['minimum_net_assets_yi']) & observed
    held = daily.holding.iloc[-1]
    if scheduled:
        index, _ = base.winner(mom.to_numpy(), assets.to_numpy(), observed.to_numpy(), cfg['minimum_net_assets_yi'])
        selected = mom.index[index] if index >= 0 else 'CASH'
        reason = 'scheduled_selection'
    else:
        selected = held if held != 'CASH' and eligible[held] else 'CASH'
        reason = 'eligibility_exit' if held != 'CASH' and selected == 'CASH' else 'weekly_hold'
    sigma = float(vol.loc[date,selected]) if selected != 'CASH' else None
    target = risk_weight(sigma,cfg['target_vol']) if sigma is not None else 0.0
    before = float(daily.exposure.iloc[-1]) if held == selected and held != 'CASH' else 0.0
    trade, sizing_reason = rebalance_gate(before,target,sigma if sigma is not None else np.nan,
                                         cfg['target_vol'],cfg['primary_band'],cfg['risk_buffer'],held != selected)
    plan_weight = target if trade else before
    # Independent ranking and eligibility check for the not-yet-executed plan.
    ranked = mom.loc[eligible].sort_values(ascending=False, kind='stable')
    expected = ranked.index[0] if scheduled and len(ranked) else ('CASH' if scheduled else
               held if held != 'CASH' and bool(eligible[held]) else 'CASH')
    assert selected == expected and execution > date
    candidates = []
    for symbol in SYMBOLS:
        m = float(mom[symbol]); price = float(closes.loc[date,symbol]); ma = float(panel['weekly_ma'].loc[date,symbol])
        sigma_s = float(vol.loc[date,symbol])
        if not all(np.isfinite([m,price,ma,sigma_s,assets[symbol]])):
            raise ValueError('Latest candidate has incomplete warmup or scale')
        candidates.append(dict(symbol=symbol,name=NAMES[symbol],code=symbol[2:],momentum=m,
                          maDistance=price/ma-1,assetsYi=float(assets[symbol]),volatility=sigma_s,
                          eligible=bool(eligible[symbol]),theoreticalWeight=risk_weight(sigma_s,cfg['target_vol'])))
    candidates.sort(key=lambda c:c['momentum'],reverse=True)
    return dict(signalDate=str(date.date()),executionDate=str(execution.date()),asset=selected,
                previousAsset=held,selection=bool(scheduled),reason=reason,traded=bool(trade),
                target=float(target),plannedWeight=float(plan_weight),sizingReason=sizing_reason,
                status='pending_next_open',auditPassed=True), candidates


def build_record(seed, directory, end, execution):
    cfg = dict(seed['config'], symbols=SYMBOLS, weekly_exit_on_ineligible=True,last_week_complete=True)
    base.DATA = directory
    panel, _, manifest, _, _ = base.load_market(cfg,str(end.date()))
    start = int(panel['close'].index.searchsorted(pd.Timestamp(cfg['backtest_start'])))
    full, fills, review = base.simulate_weekly(panel,cfg,start,allowed=SYMBOLS)
    selection_audit = base.audit(panel,cfg,full,fills,review,allowed=SYMBOLS)
    vol = volatility_panel(panel['raw_close'],cfg['volatility_window'])
    options = dict(target=cfg['target_vol'],band=cfg['primary_band'],risk_buffer=cfg['risk_buffer'])
    daily, trades, sizing = simulate(panel,cfg,start,review,vol,**options)
    sized_audit = audit(panel,cfg,start,review,daily,trades,sizing,cfg['volatility_window'],**options)
    baseline = pd.read_csv(io.StringIO(seed['acceptedDaily']),parse_dates=['date']).set_index('date')
    actual = daily.loc[baseline.index]
    np.testing.assert_allclose(actual.nav,baseline.nav,rtol=1e-10,atol=1e-12)
    assert actual.holding.equals(baseline.holding)
    np.testing.assert_allclose(actual.exposure,baseline.exposure,rtol=1e-10,atol=1e-12)
    pending, candidates = next_signal(panel,cfg,daily,vol,execution)
    history=[]; peak=1.0
    for date,row in daily.iterrows():
        peak=max(peak,float(row.nav))
        record=dict(date=str(date.date()),nav=float(row.nav),exposure=float(row.exposure),drawdown=float(row.nav/peak-1))
        for symbol in SYMBOLS:
            record[symbol]=float(panel['close'].loc[date,symbol]/panel['close'].iloc[start-1][symbol])
        history.append(record)
    decisions=[]
    for _,row in review.tail(52).iloc[::-1].iterrows():
        size=sizing.loc[sizing.date.eq(row.date)].iloc[0]
        decisions.append(dict(signalDate=str(pd.Timestamp(row.weekly_signal_date).date()),
            executionDate=str(pd.Timestamp(row.date).date()),asset=row.actual_holding,selection=bool(row.is_selection_day),
            reason=row.decision_reason,sizingReason=size.decision_reason,traded=bool(size.should_rebalance),
            target=float(size.target_weight),openWeight=float(size.actual_open_weight)))
    return dict(schemaVersion=1,strategyId='two-etf-v1',title='双市场趋势',mode='automated_weekly',
        generatedAt=datetime.now(ZoneInfo('UTC')).isoformat(),priceAsOf=str(end.date()),signalAsOf=str(end.date()),
        executionDate=decisions[0]['executionDate'],holding=daily.holding.iloc[-1],exposure=float(daily.exposure.iloc[-1]),
        lastTarget=float(sizing.iloc[-1].target_weight),lastSizingReason=sizing.iloc[-1].decision_reason,
        nav=float(daily.nav.iloc[-1]),summary=metrics(daily,252),annual=annual_drawdown(daily),
        candidates=candidates,history=history,decisions=decisions,pendingSignal=pending,
        nextRefreshExpected=str(execution.to_period('W-FRI').end_time.date()),
        rules=dict(momentumWeeks=26,maWeeks=40,selectionWeeks=4,targetVol=.2,volatilityDays=63,band=.05,riskLimit=.22,minAssetsYi=10),
        provenance=dict(priceHashes=manifest['hashes'],selectionAudit=selection_audit,portfolioAudit=sized_audit,
                        acceptedBaselineIdentical=True,acceptedBaselineThrough=seed['anchor'],
                        calendarHash=manifest['calendarSha256'],priceCrosscheck=manifest['priceCrosscheck'],
                        dataSources=[source.SINA_URL,source.SINA_FACTOR_URL,source.SCALE_URL,CALENDAR_URL,
                                     'https://web.ifzq.gtimg.cn/appstock/app/fqkline/get']))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--site',type=Path,required=True)
    parser.add_argument('--seed',type=Path,default=Path(__file__).with_name('weekly_seed.enc.json'))
    parser.add_argument('--as-of',default=None)
    parser.add_argument('--direct-network',action='store_true')
    args=parser.parse_args()
    password=os.environ.get('APP_PASSWORD','')
    if not password: raise ValueError('Create the APP_PASSWORD GitHub repository secret before running')
    seed_envelope=json.loads(args.seed.read_text(encoding='utf8'))
    seed=unseal(seed_envelope,password)
    client=source.session()
    if args.direct_network: client.trust_env=False
    now=datetime.now(ZoneInfo('Asia/Shanghai'))
    safe_day=pd.Timestamp(now.date()) if now.hour>=18 else pd.Timestamp(now.date())-pd.Timedelta(days=1)
    as_of=pd.Timestamp(args.as_of) if args.as_of else safe_day
    if as_of>safe_day: raise ValueError('Cannot use future or unfinished daily quotes')
    calendar,_=fetch_calendar()
    end,execution=complete_week(calendar,as_of)
    if end<pd.Timestamp(seed['anchor']): raise ValueError('Latest complete week precedes accepted baseline')
    workroot=args.site.resolve().parent/'.weekly-work'
    workroot.mkdir(parents=True,exist_ok=True)
    directory=workroot/('run-'+uuid.uuid4().hex)
    directory.mkdir()
    try:
        assert directory.resolve().is_relative_to(workroot.resolve())
        fetch_snapshot(seed,directory,calendar,end)
        record=build_record(seed,directory,end,execution)
        salt=__import__('base64').b64decode(seed_envelope['salt'])
        args.site.mkdir(parents=True,exist_ok=True)
        write_sealed(args.site/'data.enc.json',record,password,salt=salt)
    finally:
        # A checked, freshly-created child of our explicit working directory only.
        assert directory.resolve().is_relative_to(workroot.resolve())
        shutil.rmtree(directory)
    # Log only dates/audit status. Strategy details remain inside the encrypted data.
    print('PASS: prices through',record['priceAsOf'],'pending next open',record['pendingSignal']['executionDate'],
          '; accepted baseline, causal selection and portfolio audits passed.')
    summary=os.environ.get('GITHUB_STEP_SUMMARY')
    if summary:
        with open(summary,'a',encoding='utf8') as f:
            f.write(f"Updated encrypted data through {record['priceAsOf']}; next open {record['pendingSignal']['executionDate']}. All audits passed.\n")


if __name__=='__main__':
    try:
        main()
    except AssertionError:
        raise SystemExit('Historical baseline or strategy audit failed; publication aborted.') from None
