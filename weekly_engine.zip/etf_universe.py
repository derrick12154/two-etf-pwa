"""Public ETF registry, quarterly net assets, and adjusted daily market data."""
from __future__ import annotations

import hashlib
import html
import io
import json
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from market_data import ENDPOINT, validate_frame

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data" / "etf_weekly"
REGISTRY_URL = "https://fund.eastmoney.com/js/fundcode_search.js"
SCALE_URL = "https://fundf10.eastmoney.com/FundArchivesDatas.aspx"
_LOCAL = threading.local()
_GATE_LOCK = threading.Lock()
_DECODER_LOCK = threading.Lock()
_LAST_REQUEST = {"scale": 0.0, "price": 0.0}
SINA_URL = "https://finance.sina.com.cn/realstock/company/{symbol}/hisdata_klc2/klc_kl.js"
SINA_FACTOR_URL = "https://finance.sina.com.cn/realstock/company/{symbol}/hfq.js"
FACTOR_DATE_OVERRIDES = {"sh510500": {"2022-08-26": "2022-08-29"}}
SPLIT_SOURCE = "https://www.sse.com.cn/disclosure/fund/announcement/c/new/2022-08-23/510500_20220823_1_aMMa3ZNB.pdf"
FOREIGN = r"港|恒生|纳指|日经|德国|美国|法国|海外|全球|越南|韩国|印度|中概|东南亚|沙特|日本|巴西|新兴市场|亚太|欧洲|QDII"


def foreign_name_mask(names):
    # Hang Seng also publishes explicitly A-share indices; its brand is not a market.
    normalized = names.fillna("").str.replace("恒生A股", "A股", regex=False).str.replace("恒生前海", "", regex=False)
    return normalized.str.contains(FOREIGN, case=False, regex=True)


def session():
    if not hasattr(_LOCAL, "session"):
        client = requests.Session()
        client.headers.update({"User-Agent": "Mozilla/5.0", "Referer": "https://fund.eastmoney.com/"})
        client.mount("https://", HTTPAdapter(max_retries=Retry(total=3, backoff_factor=0.5,
                                                               status_forcelist=[429, 500, 502, 503, 504])))
        _LOCAL.session = client
    return _LOCAL.session


def public_get(url, params, category):
    # Honor the scale service's frequency cap. Concurrent work shares one gate.
    interval = 0.75 if category == "scale" else 0.35
    for attempt in range(4):
        with _GATE_LOCK:
            wait = interval - (time.monotonic() - _LAST_REQUEST[category])
            if wait > 0:
                time.sleep(wait)
            _LAST_REQUEST[category] = time.monotonic()
        response = session().get(url, params=params, timeout=25)
        if response.status_code in [429, 514]:
            delay = max(60.0, float(response.headers.get("Retry-After", 60)))
            with _GATE_LOCK:
                _LAST_REQUEST[category] = time.monotonic() + delay
            if attempt == 3:
                response.raise_for_status()
            continue
        response.raise_for_status()
        return response
    raise RuntimeError("Public data request failed")


def registry_from_text(text):
    records = json.loads(text[text.index("["):text.rindex("]") + 1])
    frame = pd.DataFrame(records, columns=["code", "abbr", "name", "fund_type", "spell"])
    base = frame["code"].str.match(r"^(15|5)") & frame["name"].str.contains("ETF", case=False)
    frame = frame.loc[base].copy()
    frame["classification_reason"] = "included_domestic_stock_index_etf"
    frame.loc[frame["fund_type"] != "指数型-股票", "classification_reason"] = "not_stock_index_type"
    frame.loc[frame["name"].str.contains("联接|连接|后端"), "classification_reason"] = "feeder_or_other_share"
    frame.loc[foreign_name_mask(frame["name"]), "classification_reason"] = "foreign_or_mixed_market_name"
    frame["included"] = frame["classification_reason"] == "included_domestic_stock_index_etf"
    frame["symbol"] = np.where(frame["code"].str.startswith("15"), "sz", "sh") + frame["code"]
    return frame.sort_values("code").reset_index(drop=True)


def parse_scale(text):
    match = re.search(r'content:\s*"(.*?</table>)"', text, re.S)
    if not match:
        raise ValueError("No public scale table")
    # This endpoint returns an HTML string, not executable JavaScript.
    table_html = match.group(1).replace(r'\"', '"').replace(r"\n", "")
    tables = pd.read_html(io.StringIO(table_html))
    frame = tables[0]
    if frame.shape[1] < 5 or "亿元" not in str(frame.columns[4]):
        raise ValueError("Unknown net-asset units or schema")
    result = pd.DataFrame({"report_date": pd.to_datetime(frame.iloc[:, 0], errors="coerce"),
                           "net_assets_yi": pd.to_numeric(frame.iloc[:, 4].astype(str).str.replace(",", ""), errors="coerce")})
    result = result.dropna().sort_values("report_date").drop_duplicates("report_date", keep="last")
    if result.empty or (result["net_assets_yi"] < 0).any():
        raise ValueError("Invalid net assets")
    pages = re.search(r"pages\s*:\s*(\d+)", text)
    return result, int(pages.group(1)) if pages else 1


def profile_name(text):
    match = re.search(r"<th[^>]*>基金全称</th>\s*<td[^>]*>(.*?)</td>", text, re.S)
    if not match:
        raise ValueError("No public full fund name")
    return html.unescape(re.sub(r"<[^>]+>", "", match.group(1))).strip()


def fetch_profile(record, end):
    path = DATA / "raw" / "profile" / f"{record['code']}_{end}.html"
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        response = public_get(f"https://fundf10.eastmoney.com/jbgk_{record['code']}.html", {}, "scale")
        path.write_text(response.text, encoding="utf-8")
    return {"symbol": record["symbol"], "full_name": profile_name(path.read_text(encoding="utf-8"))}


def fetch_scale(record):
    code = record["code"]
    raw_dir = DATA / "raw" / "scale"
    raw_dir.mkdir(parents=True, exist_ok=True)
    frames = []
    page = 1
    while True:
        path = raw_dir / f"{code}_{page}.txt"
        if not path.exists():
            response = public_get(SCALE_URL, {"type": "gmbd", "code": code, "page": page, "per": 100}, "scale")
            path.write_text(response.text, encoding="utf-8")
        frame, total_pages = parse_scale(path.read_text(encoding="utf-8"))
        frames.append(frame)
        if page >= total_pages:
            break
        page += 1
    result = pd.concat(frames).drop_duplicates("report_date").sort_values("report_date")
    result.insert(0, "symbol", record["symbol"])
    result["available_after"] = result["report_date"] + pd.Timedelta(days=100)
    return result


def fetch_prices(record, end):
    symbol = record["symbol"]
    raw_dir = DATA / "raw" / "price" / symbol
    raw_dir.mkdir(parents=True, exist_ok=True)
    target = DATA / "prices" / f"{symbol}.csv"
    target.parent.mkdir(parents=True, exist_ok=True)
    first_year = max(2019, pd.Timestamp(record["first_scale_report"]).year - 1)
    frames = []
    for year in range(first_year, pd.Timestamp(end).year + 1):
        left = max(pd.Timestamp("2019-01-01"), pd.Timestamp(f"{year}-01-01") - pd.Timedelta(days=15))
        right = min(pd.Timestamp(end), pd.Timestamp(f"{year}-12-31"))
        path = raw_dir / f"{year}_{right.date()}.json"
        if not path.exists():
            response = public_get(ENDPOINT, {"param": f"{symbol},day,{left.date()},{right.date()},640,hfq"}, "price")
            payload = response.json()
            if payload.get("code") != 0:
                raise ValueError(f"Provider error {payload.get('msg')}")
            path.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
        payload = json.loads(path.read_text(encoding="utf-8"))
        block = payload.get("data", {}).get(symbol, {})
        rows = block.get("hfqday", block.get("day", []))
        if not rows:
            continue  # Prelisting periods can be empty; eligibility requires actual observations.
        frame = validate_frame(pd.DataFrame([row[:6] for row in rows], columns=
                                            ["date", "open", "close", "high", "low", "volume"]), symbol)
        frame = frame.loc[left:right]
        if frames:
            previous = pd.concat(frames)
            overlap = previous.index.intersection(frame.index)
            if len(overlap) and not np.allclose(previous.loc[overlap, ["open", "close", "high", "low"]],
                                               frame.loc[overlap, ["open", "close", "high", "low"]], rtol=1e-8, atol=1e-8):
                raise ValueError("Inconsistent adjusted prices in overlapping requests")
        frames.append(frame)
    if not frames:
        raise ValueError("No adjusted historical data")
    full = pd.concat(frames)
    full = full[~full.index.duplicated(keep="last")].sort_index().loc["2019-01-01":end]
    full.to_csv(target, encoding="utf-8-sig", date_format="%Y-%m-%d")
    return {"symbol": symbol, "bars": len(full), "first_price": str(full.index[0].date()),
            "last_price": str(full.index[-1].date()), "sha256": hashlib.sha256(target.read_bytes()).hexdigest()}


def sina_adjust(raw, factor_text, date_overrides=None):
    payload = json.JSONDecoder().raw_decode(factor_text.split("=", 1)[1].lstrip())[0]
    factors = pd.DataFrame(payload["data"])
    if factors.empty or not {"d", "s", "u"}.issubset(factors):
        raise ValueError("Missing ETF affine adjustment factors")
    factors["d"] = pd.to_datetime(factors["d"].replace(date_overrides or {}))
    factors = factors.set_index("d").sort_index()
    factors = factors[["s", "u"]].astype(float)
    for date in factors.index[factors.index.duplicated()].unique():
        if len(factors.loc[[date]].drop_duplicates()) != 1:
            raise ValueError("Conflicting adjustment factors on the same effective date")
    factors = factors.loc[~factors.index.duplicated(keep="last")]
    if not np.isfinite(factors.to_numpy()).all() or (factors["s"] <= 0).any():
        raise ValueError("Invalid adjustment factors")
    dividend_increment = factors["u"].diff().fillna(factors["u"])
    if (dividend_increment < -1e-8).any():
        raise ValueError("Cumulative dividend offset decreases; manual source review required")
    # u is the sum of per-share cash dividends. A split does not multiply cash
    # paid before it: weight each dividend increment by s on its ex-dividend date.
    factors["cash_offset"] = (dividend_increment * factors["s"]).cumsum()
    known = factors.reindex(factors.index.union(raw.index)).ffill().reindex(raw.index)
    if known.isna().any().any():
        raise ValueError("Adjustment factors do not cover the full price history")
    adjusted = raw.copy()
    for column in ["open", "close", "high", "low"]:
        adjusted[column] = raw[column] * known["s"] + known["cash_offset"]
    return validate_frame(adjusted.reset_index(), "sina_adjusted")


def fetch_sina_prices(record, end):
    import py_mini_racer
    from akshare.fund.fund_etf_sina import hk_js_decode
    symbol = record["symbol"]
    raw_dir = DATA / "raw" / "sina" / symbol
    raw_dir.mkdir(parents=True, exist_ok=True)
    paths = {}
    for field, url in [("bars", SINA_URL), ("factor", SINA_FACTOR_URL)]:
        path = raw_dir / f"{field}_{end}.txt"
        if not path.exists():
            response = public_get(url.format(symbol=symbol), {}, "price")
            path.write_text(response.text, encoding="utf-8")
        paths[field] = path
    # Only the installed AKShare decoder is executed; downloaded JS is parsed as data.
    text = paths["bars"].read_text(encoding="utf-8")
    encoded = json.JSONDecoder().raw_decode(text.split("=", 1)[1].lstrip())[0]
    # Serialize V8 initialization/decoding: the Windows runtime can abort on races.
    with _DECODER_LOCK:
        with py_mini_racer.MiniRacer() as decoder:
            decoder.eval(hk_js_decode)
            rows = decoder.call("d", encoded)
    raw = pd.DataFrame(rows)
    if raw.empty:
        raise ValueError("No historical Sina ETF bars")
    raw["date"] = pd.to_datetime(raw["date"], utc=True).dt.tz_localize(None)
    raw = raw.loc[(raw["date"] >= "2019-01-01") & (raw["date"] <= end)]
    volume = pd.to_numeric(raw["volume"], errors="raise")
    nontrading_dates = raw.loc[volume.eq(0), "date"]
    raw = raw.loc[~volume.eq(0)]
    raw = validate_frame(raw, symbol)
    if raw.empty:
        raise ValueError("No positive-volume ETF bars in the requested period")
    full = sina_adjust(raw, paths["factor"].read_text(encoding="utf-8"), FACTOR_DATE_OVERRIDES.get(symbol))
    target = DATA / "prices" / f"{symbol}.csv"
    target.parent.mkdir(parents=True, exist_ok=True)
    full.to_csv(target, encoding="utf-8-sig", date_format="%Y-%m-%d")
    return {"symbol": symbol, "bars": len(full), "first_price": str(full.index[0].date()),
            "last_price": str(full.index[-1].date()), "provider": "Sina ETF bars and affine hfq factors",
            "nontrading_bar_count": len(nontrading_dates),
            "nontrading_bar_dates": "|".join(nontrading_dates.dt.strftime("%Y-%m-%d")),
            "sha256": hashlib.sha256(target.read_bytes()).hexdigest()}


def download(end, workers=4, price_provider="sina"):
    DATA.mkdir(parents=True, exist_ok=True)
    raw_path = DATA / "raw" / "registry.txt"
    raw_path.parent.mkdir(parents=True, exist_ok=True)
    if not raw_path.exists():
        response = session().get(REGISTRY_URL, timeout=30)
        response.raise_for_status()
        raw_path.write_text(response.text, encoding="utf-8")
    registry = registry_from_text(raw_path.read_text(encoding="utf-8"))
    registry.to_csv(DATA / "registry.csv", index=False, encoding="utf-8-sig")
    records = registry.loc[registry["included"]].to_dict("records")
    print(f"Registry: {len(records)} domestic equity ETF candidates", flush=True)
    scales, failures = [], []
    with ThreadPoolExecutor(max_workers=workers) as pool:
        jobs = {pool.submit(fetch_scale, row): row for row in records}
        for count, job in enumerate(as_completed(jobs), 1):
            row = jobs[job]
            try:
                scales.append(job.result())
            except Exception as error:
                failures.append({"symbol": row["symbol"], "stage": "scale", "error": str(error)})
            if count % 50 == 0 or count == len(jobs):
                print(f"Scale history: {count}/{len(jobs)}, failures={len(failures)}", flush=True)
    if not scales:
        raise ValueError("No usable historical scale data")
    scale = pd.concat(scales).sort_values(["symbol", "report_date"])
    scale.to_csv(DATA / "scale_history.csv", index=False, encoding="utf-8-sig", date_format="%Y-%m-%d")
    # Include every registered ETF ever above the threshold, not just today's big funds.
    relevant = scale.loc[(scale["net_assets_yi"] > 10) & (scale["available_after"] <= pd.Timestamp(end)), "symbol"].unique()
    first = scale.groupby("symbol")["report_date"].min().rename("first_scale_report")
    universe = registry.loc[registry["symbol"].isin(relevant)].merge(first, on="symbol")
    print(f"Full-name market classification: checking {len(universe)} historically large candidates", flush=True)
    profiles = []
    with ThreadPoolExecutor(max_workers=workers) as pool:
        jobs = {pool.submit(fetch_profile, row, end): row for row in universe.to_dict("records")}
        for count, job in enumerate(as_completed(jobs), 1):
            row = jobs[job]
            try:
                profiles.append(job.result())
            except Exception as error:
                failures.append({"symbol": row["symbol"], "stage": "profile", "error": str(error)})
            if count % 50 == 0 or count == len(jobs):
                print(f"Full fund names: {count}/{len(jobs)}", flush=True)
    profiles = pd.DataFrame(profiles, columns=["symbol", "full_name"])
    registry = registry.merge(profiles, on="symbol", how="left")
    mixed = foreign_name_mask(registry["full_name"])
    registry.loc[mixed, ["included", "classification_reason"]] = [False, "foreign_or_mixed_market_full_name"]
    registry.to_csv(DATA / "registry.csv", index=False, encoding="utf-8-sig")
    excluded = registry.loc[registry["symbol"].isin(relevant) & (~registry["included"] | registry["full_name"].isna())]
    excluded.to_csv(DATA / "excluded_market_scope.csv", index=False, encoding="utf-8-sig")
    universe = universe.merge(profiles, on="symbol", how="inner")
    universe = universe.loc[~foreign_name_mask(universe["full_name"])].copy()
    print(f"Historical >1bn CNY threshold (=10 yi yuan): {len(universe)} ETFs require price history", flush=True)
    price_rows = []
    with ThreadPoolExecutor(max_workers=workers) as pool:
        fetcher = fetch_sina_prices if price_provider == "sina" else fetch_prices
        jobs = {pool.submit(fetcher, row, end): row for row in universe.to_dict("records")}
        for count, job in enumerate(as_completed(jobs), 1):
            row = jobs[job]
            try:
                price_rows.append(job.result())
            except Exception as error:
                failures.append({"symbol": row["symbol"], "stage": "price", "error": str(error)})
            if count % 20 == 0 or count == len(jobs):
                print(f"Price history: {count}/{len(jobs)}, failures={len(failures)}", flush=True)
    if failures:
        pd.DataFrame(failures).to_csv(DATA / "download_failures.csv", index=False, encoding="utf-8-sig")
    else:
        pd.DataFrame(columns=["symbol", "stage", "error"]).to_csv(DATA / "download_failures.csv", index=False)
    universe = universe.merge(pd.DataFrame(price_rows), on="symbol", how="left")
    universe.to_csv(DATA / "universe.csv", index=False, encoding="utf-8-sig", date_format="%Y-%m-%d")
    meta = {"end": end, "downloaded_at": datetime.now(timezone.utc).isoformat(), "registry_url": REGISTRY_URL,
            "scale_url": SCALE_URL, "price_url": SINA_URL if price_provider == "sina" else ENDPOINT,
            "price_provider": price_provider, "adjustment": "P*s + cumulative(s_at_event * change_in_u) from historical ETF hfq factors" if price_provider == "sina" else "hfq request; hfqday or day field",
            "factor_date_overrides": FACTOR_DATE_OVERRIDES if price_provider == "sina" else {},
            "split_correction_source": SPLIT_SOURCE,
            "registry_candidates": len(records),
            "historically_over_threshold": len(universe), "usable_prices": len(price_rows),
            "initially_over_threshold_before_full_name_check": len(relevant),
            "market_scope_exclusions": len(excluded),
            "threshold_cny": 1_000_000_000, "scale_unit": "yi yuan (1e8 CNY)", "availability_lag_days": 100,
            "failures": failures, "registry_sha256": hashlib.sha256(raw_path.read_bytes()).hexdigest(),
            "classification": "public registry type index-stock ETF, exclude feeder and foreign/mixed-market names",
            "delisted_fund_coverage": "registry may omit terminated funds; completeness not established"}
    (DATA / "manifest.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({key: meta[key] for key in ["registry_candidates", "historically_over_threshold", "usable_prices"]}), flush=True)


if __name__ == "__main__":
    import argparse
    from market_data import completed_end
    parser = argparse.ArgumentParser()
    parser.add_argument("--end", default=completed_end())
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--price-provider", choices=["sina", "tencent"], default="sina")
    options = parser.parse_args()
    download(options.end, options.workers, options.price_provider)
