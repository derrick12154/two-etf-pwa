"""Causal volatility sizing while preserving the original four-week ETF selection."""
from __future__ import annotations

import argparse
import hashlib
import html
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

import weekly_momentum as base
from strategy import allocate, metrics

ROOT = Path(__file__).resolve().parent


def volatility_panel(raw_close, window, annualization=252):
    if not isinstance(window, int) or window < 2:
        raise ValueError('Volatility window must be an integer >=2')
    result = {}
    for symbol in raw_close:
        observed = raw_close[symbol].dropna()
        vol = observed.pct_change(fill_method=None).rolling(window, min_periods=window).std(ddof=1) * np.sqrt(annualization)
        result[symbol] = vol.reindex(raw_close.index).ffill()
    return pd.DataFrame(result, index=raw_close.index)


def risk_weight(sigma, target):
    if not np.isfinite(target) or target <= 0:
        raise ValueError('Target volatility must be positive')
    if not np.isfinite(sigma):
        return 0.0
    if sigma < 0:
        raise ValueError('Negative volatility')
    return 1.0 if sigma == 0 else min(1.0, target / sigma)


def rebalance_gate(current_weight, target_weight, sigma, target, band, risk_buffer, mandatory):
    if mandatory:
        return True, 'asset_change'
    if band is None:
        return True, 'scheduled'
    if current_weight > target_weight and (not np.isfinite(sigma) or
            (risk_buffer is not None and current_weight * sigma > target * (1 + risk_buffer) + 1e-12)):
        return True, 'risk_excess'
    if abs(current_weight - target_weight) >= band - 1e-12:
        return True, 'band_exceeded'
    return False, 'hold_band'


def recovery_weight(current_weight, target_weight, max_addition, mandatory):
    if max_addition is None or mandatory or target_weight <= current_weight:
        return target_weight, False
    execution_weight=min(target_weight,current_weight+max_addition)
    return execution_weight, execution_weight < target_weight-1e-12


def simulate(panel, cfg, start, selections, forecasts, *, target=0.20, static=None, cadence='weekly',
             band=None, risk_buffer=None, max_addition=None, weekly_reduction_policy='none'):
    if weekly_reduction_policy not in ['none','positive_week','positive_week_with_risk']:
        raise ValueError('Unknown weekly reduction policy')
    if weekly_reduction_policy!='none' and (cadence!='weekly' or static is not None):
        raise ValueError('Weekly momentum guard requires weekly volatility sizing')
    if weekly_reduction_policy=='positive_week_with_risk' and risk_buffer is None:
        raise ValueError('Risk-preserving guard requires a risk buffer')
    if cadence not in ['weekly', 'four_week'] or (static is not None and not 0 <= static <= 1):
        raise ValueError('Invalid sizing policy')
    if band is not None and (not 0 < band <= 1 or static is not None):
        raise ValueError('Band must be in (0,1] and applies only to volatility sizing')
    if risk_buffer is not None and (not np.isfinite(risk_buffer) or risk_buffer < 0):
        raise ValueError('Invalid risk buffer')
    if max_addition is not None and (not np.isfinite(max_addition) or not 0 < max_addition <= 1 or static is not None):
        raise ValueError('Max addition must be in (0,1] and applies only to volatility sizing')
    dates, symbols = panel['close'].index, panel['close'].columns
    open_values, close_values = panel['open'].to_numpy(), panel['close'].to_numpy()
    tradable = panel['tradable'].to_numpy(dtype=bool)
    forecasts_array = forecasts.to_numpy()
    weekly_returns = None
    if weekly_reduction_policy!='none':
        weekly = panel.get('weekly_close')
        if weekly is None:
            weekly = base.weekly_signal_panel(panel['raw_close'],1)['weekly_close']
        weekly_returns = base.momentum_panel(weekly,1).reindex(dates,method='ffill')
    selection_map = dict(zip(pd.to_datetime(selections['date']), selections['selected']))
    selection_flags = (dict(zip(pd.to_datetime(selections['date']), selections['is_selection_day']))
                       if 'is_selection_day' in selections else {})
    scheduled = set(base.rebalance_rows(dates, start, 1 if cadence == 'weekly' else cfg['rebalance_every_weeks']))
    cash, units = float(cfg['initial_capital']), np.zeros(len(symbols))
    asset, previous = -1, cash
    rate = (cfg['commission_bps'] + cfg['slippage_bps']) / 10000
    daily, trades, sizing = [], [], []
    for row in range(start, len(dates)):
        date, signal_date = dates[row], dates[row-1]
        selection_day = bool(selection_flags.get(date, date in selection_map))
        before = np.zeros(len(symbols))
        active = units > 1e-12
        before[active] = units[active] * open_values[row, active]
        equity_open = cash + before.sum()
        cost, traded, blocked = 0.0, 0.0, False
        if date in selection_map:
            proposed = selection_map[date]
            asset = -1 if proposed == 'CASH' else symbols.get_loc(proposed)
        if row in scheduled:
            sigma = forecasts_array[row-1, asset] if asset >= 0 else np.nan
            weight = (float(static) if static is not None else risk_weight(sigma,target)) if asset >= 0 else 0.0
            weights = np.zeros(len(symbols))
            if asset >= 0:
                weights[asset] = weight
            # Gate with previous completed close; the next opening gap is not known at signal time.
            signal_value = np.zeros(len(symbols))
            signal_value[active] = units[active] * close_values[row-1, active]
            signal_equity = cash + signal_value.sum()
            signal_weight = signal_value[asset]/signal_equity if asset >= 0 else 0.0
            previous_asset = int(np.flatnonzero(active)[0]) if active.any() else -1
            mandatory = previous_asset != asset
            should_rebalance, reason = rebalance_gate(signal_weight,weight,sigma,target,band,risk_buffer,mandatory)
            week_return = weekly_returns.iloc[row-1,asset] if weekly_returns is not None and asset>=0 else np.nan
            risk_excess = signal_weight>weight and (not np.isfinite(sigma) or
                (risk_buffer is not None and signal_weight*sigma>target*(1+risk_buffer)+1e-12))
            guard = (weekly_reduction_policy!='none' and not mandatory and asset>=0 and week_return>0 and
                not (weekly_reduction_policy=='positive_week_with_risk' and risk_excess))
            reduction_veto = bool(guard and should_rebalance and signal_weight>weight+1e-12)
            if reduction_veto:
                should_rebalance,reason=False,'positive_week_hold'
            execution_weight,ramp_limited=recovery_weight(signal_weight,weight,max_addition,mandatory)
            # Positive-week protection also prevents a buy-intended adjustment
            # from selling existing units after an upward opening gap. This
            # execution floor uses only the actual opening account valuation;
            # opening prices never change the prior weekly guard/risk signal.
            execution_floor = bool(guard and should_rebalance and before[asset]/equity_open>execution_weight+1e-12)
            if execution_floor:
                execution_weight=before[asset]/equity_open
            if asset>=0:
                weights[asset]=execution_weight
            relevant = active.copy()
            if asset >= 0 and weight > 0:
                relevant[asset] = True
            blocked = should_rebalance and bool((relevant & ~tradable[row]).any())
            if should_rebalance and not blocked:
                after, cash, cost = allocate(equity_open,before,weights,rate)
                changes = after-before
                traded = abs(changes).sum()
                for col in np.flatnonzero(abs(changes)>1e-6):
                    trades.append({'date':date,'signal_date':signal_date,'symbol':symbols[col],
                                   'side':'BUY' if changes[col]>0 else 'SELL','adjusted_price':open_values[row,col],
                                   'units_delta':changes[col]/open_values[row,col], 'notional':abs(changes[col]),
                                   'cost':abs(changes[col])*rate})
                units = np.divide(after,open_values[row],out=np.zeros(len(symbols)),where=after>0)
            elif blocked and date in selection_map:
                # A blocked four-week switch retains the old asset; sizing does not retry a switch next week.
                asset = int(np.flatnonzero(active)[0]) if active.any() else -1
            actual_weight = (units[units>1e-12] * open_values[row,units>1e-12]).sum() / (equity_open-cost)
            sizing.append({'date':date,'signal_date':signal_date,'selection_day':selection_day,
                           'selected':selection_map.get(date, symbols[asset] if asset>=0 else 'CASH'),
                           'asset':symbols[asset] if asset>=0 else 'CASH','estimated_vol':sigma,
                           'target_weight':weight,'actual_open_weight':actual_weight,'blocked':blocked,
                           'signal_weight':signal_weight,'signal_risk':signal_weight*sigma if asset>=0 else 0.0,
                           'should_rebalance':should_rebalance,'decision_reason':reason,
                           'execution_target_weight':execution_weight,'ramp_limited':ramp_limited,
                           'weekly_momentum':week_return,'positive_week_guard':bool(guard),
                           'reduction_veto':reduction_veto,'execution_floor_applied':execution_floor})
        active = units > 1e-12
        position_value = float((units[active]*close_values[row,active]).sum())
        equity = cash+position_value
        if not np.isfinite(equity) or equity<=0 or cash < -1e-6:
            raise ArithmeticError('Invalid valuation')
        holding = symbols[np.flatnonzero(active)[0]] if active.any() else 'CASH'
        open_position_value=float((units[active]*open_values[row,active]).sum())
        daily.append({'date':date,'equity':equity,'nav':equity/cfg['initial_capital'],'return':equity/previous-1,
                      'cash':cash,'cash_weight':cash/equity,'exposure':position_value/equity,'cost':cost,
                      'turnover':traded/equity_open,'holding':holding,
                      'actual_open_exposure':open_position_value/(equity_open-cost),
                      'held_price_missing':active.any() and pd.isna(panel['raw_close'].loc[date,holding])})
        previous = equity
    return (pd.DataFrame(daily).set_index('date'),
            pd.DataFrame(trades,columns=['date','signal_date','symbol','side','adjusted_price','units_delta','notional','cost']),
            pd.DataFrame(sizing))


def audit(panel,cfg,start,selections,daily,trades,sizing,window,*,target=.20,static=None,cadence='weekly',
          band=None,risk_buffer=None,max_addition=None,weekly_reduction_policy='none'):
    # Independent cash/units reconstruction and independent volatility reconstruction.
    cash, holdings = float(cfg['initial_capital']), pd.Series(0.0,index=panel['close'].columns)
    rate = (cfg['commission_bps']+cfg['slippage_bps'])/10000
    by_date = {d:p for d,p in trades.groupby('date')}
    errors=[];before_positions={}
    for date,row in daily.iterrows():
        before_positions[date]=(cash,holdings.copy())
        for _,fill in by_date.get(date,pd.DataFrame()).iterrows():
            assert fill.signal_date < date and panel['tradable'].loc[date,fill.symbol]
            assert np.isclose(fill.adjusted_price,panel['open'].loc[date,fill.symbol])
            assert np.isclose(abs(fill.units_delta)*fill.adjusted_price,fill.notional)
            assert np.isclose(fill.cost,rate*fill.notional)
            cash -= (1 if fill.side=='BUY' else -1)*fill.notional+fill.cost
            holdings.loc[fill.symbol]+=fill.units_delta
        held=holdings.abs()>1e-7
        assert held.sum()<=1 and cash>=-1e-5
        equity=cash+(holdings.loc[held]*panel['close'].loc[date,held]).sum()
        errors.append(abs(equity-row.equity))
        assert abs(row.cash-cash)<1e-5 and -1e-12<=row.exposure<=1+1e-10
        assert row.holding==(holdings.index[held][0] if held.any() else 'CASH')
    assert max(errors)<1e-4 and np.isclose(daily.cost.sum(),trades.cost.sum(),atol=1e-5)
    calendar=pd.Series(daily.index,index=daily.index).groupby(daily.index.to_period('W-FRI')).first()
    assert list(sizing.date)==list(calendar.iloc[::1 if cadence=='weekly' else cfg['rebalance_every_weeks']])
    assert set(trades.date).issubset(set(sizing.date))
    selection_map=dict(zip(selections.date,selections.selected))
    for _,r in sizing.iterrows():
        assert r.signal_date==panel['close'].index[panel['close'].index.get_loc(r.date)-1]
        if r.date in selection_map:
            assert r.selected==selection_map[r.date]
        if not r.blocked:
            expected=0.0
            if r.asset!='CASH':
                raw=panel['raw_close'].loc[:r.signal_date,r.asset].dropna()
                independent=raw.pct_change(fill_method=None).dropna().iloc[-window:]
                sigma=float(independent.std(ddof=1)*np.sqrt(cfg['annualization'])) if len(independent)==window else np.nan
                assert np.isclose(r.estimated_vol,sigma,equal_nan=True)
                expected=float(static) if static is not None else risk_weight(sigma,target)
            assert np.isclose(r.target_weight,expected)
            prior_cash,prior_units=before_positions[r.date]
            active=prior_units.abs()>1e-7
            old_asset=prior_units.index[active][0] if active.any() else 'CASH'
            signal_values=prior_units.loc[active]*panel['close'].loc[r.signal_date,active]
            equity=prior_cash+signal_values.sum()
            signal_weight=float(signal_values.get(r.asset,0.0)/equity)
            assert np.isclose(r.signal_weight,signal_weight)
            should=(old_asset!=r.asset or band is None)
            if band is not None:
                excess=(signal_weight>expected and (not np.isfinite(r.estimated_vol) or
                        (risk_buffer is not None and signal_weight*r.estimated_vol>target*(1+risk_buffer)+1e-12)))
                should |= excess or abs(signal_weight-expected)>=band-1e-12
            protected=False
            if weekly_reduction_policy!='none':
                one_week=np.nan
                if r.asset!='CASH':
                    history=panel['raw_close'].loc[:r.signal_date,r.asset]
                    closes=history.groupby(history.index.to_period('W-FRI')).last().dropna()
                    if len(closes)>=2:one_week=float(closes.iloc[-1]/closes.iloc[-2]-1)
                    # If the current market week has no quote for this asset,
                    # there is no positive current-week observation to guard.
                    all_weeks=panel['raw_close'].loc[:r.signal_date].groupby(
                        panel['raw_close'].loc[:r.signal_date].index.to_period('W-FRI')).last()
                    if pd.isna(all_weeks[r.asset].iloc[-1]):one_week=np.nan
                assert np.isclose(r.weekly_momentum,one_week,equal_nan=True)
                above_risk=(signal_weight>expected and (not np.isfinite(r.estimated_vol) or
                    (risk_buffer is not None and signal_weight*r.estimated_vol>target*(1+risk_buffer)+1e-12)))
                protected=(old_asset==r.asset and r.asset!='CASH' and one_week>0 and
                    not (weekly_reduction_policy=='positive_week_with_risk' and above_risk))
                veto=bool(protected and should and signal_weight>expected+1e-12)
                assert bool(r.positive_week_guard)==bool(protected)
                assert bool(r.reduction_veto)==veto
                if veto:should=False
            assert bool(r.should_rebalance)==bool(should)
            execution_expected=expected
            if max_addition is not None and old_asset==r.asset and expected>signal_weight:
                execution_expected=min(expected,signal_weight+max_addition)
            floor=False
            if protected and should:
                opening_values=prior_units.loc[active]*panel['open'].loc[r.date,active]
                open_equity=prior_cash+opening_values.sum()
                open_weight=float(opening_values.get(r.asset,0.)/open_equity)
                floor=open_weight>execution_expected+1e-12
                execution_expected=max(execution_expected,open_weight)
            if weekly_reduction_policy!='none':
                assert bool(r.execution_floor_applied)==bool(floor)
                if protected:
                    fills=by_date.get(r.date,pd.DataFrame(columns=['side']))
                    assert not fills.side.eq('SELL').any()
            assert np.isclose(r.execution_target_weight,execution_expected)
            assert bool(r.ramp_limited)==bool(max_addition is not None and execution_expected<expected-1e-12)
            if should:
                assert np.isclose(r.actual_open_weight,execution_expected,atol=1e-9)
            else:
                assert by_date.get(r.date,pd.DataFrame()).empty
                row_daily=daily.loc[r.date]
                assert abs(row_daily.cost)<1e-8
        else:
            assert by_date.get(r.date,pd.DataFrame()).empty
    return {'passed':True,'max_equity_error_cny':max(errors),'fills':len(trades),'sizing_decisions':len(sizing),
            'blocked_sizing':int(sizing.blocked.sum()),'held_missing_price_days':int(daily.held_price_missing.sum())}


def drawdown_details(frame):
    nav=frame.nav
    dd=nav/nav.cummax().clip(lower=1)-1
    trough=dd.idxmin(); peak=nav.loc[:trough].idxmax()
    after=nav.loc[trough:]
    recovered=after[after>=nav.loc[peak]]
    underwater=nav<nav.cummax().clip(lower=1)
    longest=current=0
    for flag in underwater:
        current=current+1 if flag else 0
        longest=max(longest,current)
    y=frame.loc['2026']
    previous=nav.loc[:'2025-12-31'].iloc[-1]
    year_dd=y.nav/y.nav.cummax().clip(lower=previous)-1
    return {'peak_date':str(peak.date()),'trough_date':str(trough.date()),
            'recovered_date':str(recovered.index[0].date()) if len(recovered) else '未恢复',
            'longest_underwater_days':longest,'year_2026_return':float(y.nav.iloc[-1]/previous-1),
            'year_2026_max_drawdown':float(year_dd.min()),
            'original_crash_return':float(nav.loc['2026-07-30']/nav.loc['2026-06-25']-1)}


def render(out,results,summary,annual,costs,review):
    labels=review['labels']
    fig,axes=plt.subplots(3,1,figsize=(12,11),sharex=True)
    for key in ['full','vol20','static75','matched_static']:
        f=results[key]
        english={'full':'Full position','vol20':'20% target volatility, weekly sizing',
                 'static75':'75% constant target weight','matched_static':'Matched mean exposure (ex-post diagnostic)'}[key]
        axes[0].plot(f.index,f.nav,label=english)
        axes[1].plot(f.index,f.nav/f.nav.cummax().clip(lower=1)-1,label=english)
    axes[2].plot(results['vol20'].index,results['vol20'].exposure,label='Actual exposure: target volatility 20%')
    axes[2].set_ylim(0,1.05)
    for ax in axes:
        ax.grid(alpha=.2);ax.legend(fontsize=8)
    for ax,label in zip(axes,['Net asset value','Drawdown','ETF exposure']):ax.set_ylabel(label)
    fig.suptitle('Four-ETF momentum | asset selection unchanged | volatility sizing only')
    fig.tight_layout();fig.savefig(out/'equity_drawdown.png',dpi=160);plt.close(fig)
    cols=['annual_return','annual_vol','max_drawdown','sharpe_zero_rf','average_exposure',
          'year_2026_return','year_2026_max_drawdown','original_crash_return','longest_underwater_days']
    display=summary[cols].copy()
    display.index=display.index.map(labels)
    for col in cols:
        if col not in ['sharpe_zero_rf','longest_underwater_days']:
            display[col]=display[col].map(lambda x:f'{x:.2%}')
    display.sharpe_zero_rf=display.sharpe_zero_rf.map(lambda x:f'{x:.2f}')
    display.rename(columns={'annual_return':'年化收益','annual_vol':'实际年化波动','max_drawdown':'最大回撤',
                            'sharpe_zero_rf':'夏普','average_exposure':'平均股票仓位','year_2026_return':'2026收益',
                            'year_2026_max_drawdown':'2026最大回撤','original_crash_return':'6/25至7/30收益',
                            'longest_underwater_days':'最长水下交易日'},inplace=True)
    years=annual.pivot(index='year',columns='variant',values='return')[['full','vol20','static75','matched_static']]
    years.columns=years.columns.map(labels)
    years=years.apply(lambda s:s.map(lambda x:f'{x:.2%}'))
    cs=costs[['cost_bps','annual_return','max_drawdown','sharpe_zero_rf']].copy()
    for c in ['annual_return','max_drawdown']:cs[c]=cs[c].map(lambda x:f'{x:.2%}')
    cs.rename(columns={'cost_bps':'单边成本bp','annual_return':'年化收益','max_drawdown':'最大回撤','sharpe_zero_rf':'夏普'},inplace=True)
    primary,full,matched=summary.loc['vol20'],summary.loc['full'],summary.loc['matched_static']
    four_week=summary.loc['vol20_four_week']
    annual_numbers=annual.pivot(index='year',columns='variant',values='return')
    page=f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>四ETF波动率仓位验证</title>
<style>body{{background:#f3f5f9;color:#172033;font:15px/1.8 'Microsoft YaHei',sans-serif}}main{{max-width:1300px;margin:32px auto;padding:0 20px}}section{{background:white;border-radius:12px;padding:24px;margin:18px 0}}table{{border-collapse:collapse;white-space:nowrap;width:100%}}td,th{{padding:8px;text-align:right;border-bottom:1px solid #ddd}}th:first-child,td:first-child{{text-align:left}}.scroll{{overflow:auto}}img{{width:100%}}a{{color:#285fca}}</style>
<main><h1>四ETF：只验证波动率调整仓位</h1><p>{summary.loc['full','start']}—{summary.loc['full','end']} · 保留原选强与40周均线条件 · 不增加提前退出规则</p>
<section><h2>本次验证结论</h2><p>20%主方案年化收益{primary['annual_return']:.2%}、最大回撤{abs(primary['max_drawdown']):.2%}，满仓版分别为{full['annual_return']:.2%}、{abs(full['max_drawdown']):.2%}。降低风险的代价是低于满仓版的长期收益。相近平均仓位的静态对照年化{matched['annual_return']:.2%}、最大回撤{abs(matched['max_drawdown']):.2%}，本次样本支持动态仓位具有超出简单降仓的作用。</p>
<p>主方案实际年化波动{primary['annual_vol']:.2%}，平均仓位{primary['average_exposure']:.2%}；2026年6月25日至7月30日跌幅从{abs(full['original_crash_return']):.2%}缩小至{abs(primary['original_crash_return']):.2%}。期间仍持有创成长，随着估计风险上升而减仓；没有因均线或价格下跌提前退出。</p>
<p>改善并非覆盖每个下跌阶段：2022年主方案收益{annual_numbers.loc[2022,'vol20']:.2%}，满仓版{annual_numbers.loc[2022,'full']:.2%}，差别很小；最长净值未创新高时间仍有{int(primary['longest_underwater_days'])}个交易日，满仓版为{int(full['longest_underwater_days'])}日。主方案全期最深回撤发生在{primary['peak_date']}—{primary['trough_date']}，至{primary['recovered_date']}才恢复该峰值。</p>
<p>每周调整并非这次改善的主要来源：仅在原4周调仓日更新风险仓位，年化{four_week['annual_return']:.2%}、最大回撤{abs(four_week['max_drawdown']):.2%}，接近主方案，且成交更少。该比较用于判断机制与执行频率的贡献，不按收益最高者重新定义主方案。</p></section>
<section><h2>主方案与对照</h2><p>主方案在查看试验结果前固定为20%年化波动目标、63个真实报价日收益估计、每周调整仓位；15%/25%目标及21/126日窗口仅用于敏感性检查，不按结果选择最优参数。</p>
<div class="scroll">{display.to_html(border=0)}</div><img src="equity_drawdown.png" alt="净值、回撤与实际仓位"></section>
<section><h2>执行规则</h2><ol><li>标的仍为159967、159915、159949、513100。每4根有效市场周线比较26周涨幅，先要求涨幅为正、周收盘高于40周算术均线及滞后净资产大于10亿元，然后选最强一只；不合格则现金。</li>
<li>风险仓位＝min(100%，目标年化波动÷该ETF预估年化波动)。预估值是最近63个真实收盘收益的样本标准差（ddof=1）×√252，至少需要64个报价。不插入停牌的零收益；跨缺失日期的真实报价收益作为一个观察值，因此供应商缺失报价仍影响估计。</li>
<li>每个市场有效周收盘计算仓位，下一周首个交易日开盘调整。期间保持ETF名单；风险调整不重新检查均线或动量、不触发提前退出，不买次强标的。另测只在原4周调仓日调整风险仓位。</li>
<li>目标仓位最高100%、不加杠杆，现金收益0；两次调整之间仓位随价格漂移。20%是风险预算参考值，不保证实际波动为20%，也不是20%回撤上限。</li>
<li>按真实开盘、扣费后净资产求解买卖金额，单边佣金3bp＋滑点2bp；换ETF两边计费，调同一ETF仓位也计费。缺失/不可成交时冻结，原4周换仓被冻结后不在下一周补做换标的。</li></ol></section>
<section><h2>是否只是降低平均仓位</h2><p>固定50%和75%仓位是预先指定对照；平均仓位匹配对照为{review['matched_static_weight']:.2%}固定目标，其全期平均实际仓位与主方案相近。匹配权重用完整样本事后求解，只作风险归因，不是可预先选定的交易参数。应同时比较平均仓位、实际波动、夏普、年度收益与回撤，不能仅因回撤小就认定动态仓位更好。</p></section>
<section><h2>年度表现</h2><div class="scroll">{years.to_html(border=0)}</div><p>2026为部分年度；所有版本从相同初始现金连续核算，包含跨年持仓与费用。</p></section>
<section><h2>成本敏感性：20%主方案</h2><div class="scroll">{cs.to_html(index=False,border=0)}</div></section>
<section><h2>核对与局限</h2><p>满仓对照逐日净值与此前报告吻合；所有实验共享同一4周选ETF记录。逐笔独立重建现金与净值，重新计算每次仓位信号的历史波动率，检查成交时点、单标的持仓及不借款约束。估计波动滞后，突发跳空不能提前预测，波动上升后减仓也可能错过反弹。</p>
<p>沿用公开报价快照、报告日后100天可用的规模近似、连续复权单位；未模拟最低佣金、100份单位、一般涨跌停与所有盘中停牌。用户基于高波动、攻击性主动指定标的。本次是在已查看历史上检验新增仓位机制，不能当作前瞻验证。</p>
<p><a href="summary.csv">全部指标</a> · <a href="annual_returns.csv">年度收益</a> · <a href="vol20_daily.csv">主方案逐日仓位</a> · <a href="vol20_sizing.csv">主方案风险决策</a> · <a href="vol20_trades.csv">主方案成交</a> · <a href="selection_decisions.csv">共同选ETF记录</a> · <a href="annualized_volatility.csv">预估波动率</a> · <a href="crash_path.csv">今年回撤期间逐日对照</a> · <a href="metadata.json">配置与独立核对</a></p>
<p>复现：<code>python volatility_research.py --config volatility_config.json</code>。<a href="../etf_four/report.html">返回原满仓报告</a>。研究背景：<a href="https://doi.org/10.1016/j.jfineco.2014.11.010">Momentum Has Its Moments</a>；本文研究对象与此四ETF策略不同，不直接移用其效果结论。</p></section></main></html>'''
    (out/'report.html').write_text(page,encoding='utf8')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',default='volatility_config.json')
    args=parser.parse_args()
    research=json.loads((ROOT/args.config).read_text(encoding='utf8'))
    cfg=json.loads((ROOT/research['base_config']).read_text(encoding='utf8'))
    if pd.Timestamp(research['end'])>pd.Timestamp(base.completed_end()):raise ValueError('Incomplete daily bar')
    base.DATA=ROOT/cfg['data_dir']
    panel,universe,manifest,benchmark,gaps=base.load_market(cfg,research['end'])
    out=ROOT/research['output_dir'];out.mkdir(parents=True,exist_ok=True)
    start=int(panel['close'].index.searchsorted(pd.Timestamp(cfg['backtest_start'])))
    full,trades,selections=base.simulate_weekly(panel,cfg,start)
    base_audit=base.audit(panel,cfg,full,trades,selections)
    previous=pd.read_csv(ROOT/'output/etf_four/all_etf_daily.csv',parse_dates=['date']).set_index('date')
    np.testing.assert_allclose(full.nav,previous.nav,rtol=1e-12,atol=1e-12)
    assert full.holding.equals(previous.holding)
    forecasts=volatility_panel(panel['raw_close'],research['volatility_window'],cfg['annualization'])
    results={'full':full};audits={'full':base_audit};labels={'full':'原策略：单只满仓'}
    def run(key,label,window=None,**params):
        forecast=forecasts if window is None else volatility_panel(panel['raw_close'],window,cfg['annualization'])
        f,t,s=simulate(panel,cfg,start,selections,forecast,**params)
        audits[key]=audit(panel,cfg,start,selections,f,t,s,window or research['volatility_window'],**params)
        results[key]=f;labels[key]=label
        base.save(t,out/f'{key}_trades.csv',index=False);base.save(s,out/f'{key}_sizing.csv',index=False)
        return f
    primary=run('vol20','主方案：20%波动目标',target=research['primary_target_vol'])
    assert primary.holding.equals(full.holding), 'Sizing added an unintended asset switch or early exit'
    for target in research['target_vol_sensitivity']:
        run(f'vol{int(target*100)}',f'{target:.0%}波动目标（敏感性）',target=target)
    for weight in research['static_weights']:
        run(f'static{int(weight*100)}',f'固定{weight:.0%}目标仓位',static=weight)
    run('vol20_four_week','20%波动目标：仅4周调仓日调整',target=research['primary_target_vol'],cadence='four_week')
    for window in research['window_sensitivity']:
        run(f'vol20_window{window}',f'20%波动目标：{window}日估计（敏感性）',target=research['primary_target_vol'],window=window)
    lo,hi=0.0,1.0
    for _ in range(16):
        mid=(lo+hi)/2
        f,_,_=simulate(panel,cfg,start,selections,forecasts,static=mid)
        if f.exposure.mean()>primary.exposure.mean():hi=mid
        else:lo=mid
    matched=(lo+hi)/2
    run('matched_static','平均仓位匹配静态对照（事后归因）',static=matched)
    summary=pd.DataFrame({key:{**metrics(f,cfg['annualization']),**drawdown_details(f)} for key,f in results.items()}).T
    summary.index.name='variant'
    base.save(summary,out/'summary.csv')
    for key,f in results.items():base.save(f,out/f'{key}_daily.csv')
    base.save(trades,out/'full_trades.csv',index=False);base.save(selections,out/'selection_decisions.csv',index=False)
    base.save(forecasts,out/'annualized_volatility.csv')
    annual=pd.DataFrame([{'variant':key,'year':int(y),'return':float((1+p['return']).prod()-1)}
                         for key,f in results.items() for y,p in f.groupby(f.index.year)])
    base.save(annual,out/'annual_returns.csv',index=False)
    costs=[]
    for cost in [0,5,10,20]:
        scenario={**cfg,'commission_bps':cost,'slippage_bps':0}
        f,t,s=simulate(panel,scenario,start,selections,forecasts,target=research['primary_target_vol'])
        audit(panel,scenario,start,selections,f,t,s,research['volatility_window'],target=research['primary_target_vol'])
        costs.append({'cost_bps':cost,**metrics(f,cfg['annualization'])})
    costs=pd.DataFrame(costs);base.save(costs,out/'costs.csv',index=False)
    crash=pd.DataFrame({f'{key}_{column}':results[key][column] for key in ['full','vol20','matched_static']
                        for column in ['nav','exposure','return']}).loc['2026-06-25':'2026-08-03']
    base.save(crash,out/'crash_path.csv')
    review={'base_config':cfg,'research_config':research,'data_manifest':manifest,'audits':audits,'labels':labels,
            'matched_static_weight':matched,'matched_average_exposure_error':float(results['matched_static'].exposure.mean()-primary.exposure.mean()),
            'price_hashes':dict(zip(universe.symbol,universe.sha256)),
            'scale_history_sha256':hashlib.sha256((base.DATA/'scale_history.csv').read_bytes()).hexdigest()}
    (out/'metadata.json').write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf8')
    render(out,results,summary,annual,costs,review)
    original=ROOT/'output/etf_four/report.html'
    content=original.read_text(encoding='utf8')
    link='<p><a href="../etf_volatility/report.html">新增验证：波动率调整仓位</a></p>'
    if '../etf_volatility/report.html' not in content:original.write_text(content.replace('<main>','<main>'+link,1),encoding='utf8')
    print(summary[['annual_return','annual_vol','max_drawdown','sharpe_zero_rf','average_exposure','year_2026_max_drawdown','original_crash_return']].to_string())
    print('Matched static target:',matched)
    print('Report:',out/'report.html')


if __name__=='__main__':main()
