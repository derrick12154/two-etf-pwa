"""Single-ETF full-investment momentum research with observed-week signals."""
from __future__ import annotations

import argparse
import hashlib
import html
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from etf_universe import DATA
from market_data import completed_end, validate_frame
from strategy import metrics

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "output" / "etf_weekly"


def momentum_panel(raw_close, window):
    # Count each ETF's observed bars; missing/suspended bars do not create prices.
    return pd.DataFrame({symbol: raw_close[symbol].dropna().pct_change(window, fill_method=None).reindex(raw_close.index)
                         for symbol in raw_close}, index=raw_close.index)


def weekly_signal_panel(raw_close, window, ma_weeks=None, *, last_week_complete=False):
    periods = raw_close.index.to_period("W-FRI")
    closes = raw_close.groupby(periods).last()
    ends = pd.Series(raw_close.index, index=raw_close.index).groupby(periods).last()
    # An unconfirmed final partial week cannot enter a completed-week signal.
    if raw_close.index[-1].weekday() != 4 and not last_week_complete:
        closes, ends = closes.iloc[:-1], ends.iloc[:-1]
    closes.index = pd.DatetimeIndex(ends.to_numpy(), name="date")
    momentum = momentum_panel(closes, window)
    result = {"weekly_close": closes, "weekly_momentum": momentum,
            "momentum": momentum.reindex(raw_close.index, method="ffill"),
            "signal_observed": closes.notna().reindex(raw_close.index, method="ffill").eq(True)}
    if ma_weeks is not None:
        if not isinstance(ma_weeks, int) or ma_weeks < 1:
            raise ValueError("trend_ma_weeks must be a positive integer")
        ma = pd.DataFrame({symbol: closes[symbol].dropna().rolling(ma_weeks, min_periods=ma_weeks).mean().reindex(closes.index)
                           for symbol in closes}, index=closes.index)
        result.update({"weekly_ma": ma, "trend_ma": ma.reindex(raw_close.index, method="ffill"),
                       "trend_pass": closes.gt(ma).reindex(raw_close.index, method="ffill").eq(True)})
    return result


def rebalance_rows(dates, start, every=1):
    if not isinstance(every, int) or every < 1:
        raise ValueError("rebalance_every_weeks must be a positive integer")
    weeks = dates.to_period("W-FRI")
    new_week = np.r_[True, weeks[start + 1:] != weeks[start:-1]]
    # Count observed market weeks, so a full exchange holiday does not count.
    count = np.cumsum(new_week) - 1
    return np.flatnonzero(new_week & (count % every == 0)) + start


def scale_panel(history, dates, symbols, lag_days):
    values_by_symbol = {}
    for symbol in symbols:
        frame = history.loc[history["symbol"] == symbol].copy()
        frame["known_date"] = pd.to_datetime(frame["report_date"]) + pd.Timedelta(days=lag_days)
        frame = frame.sort_values("known_date").drop_duplicates("known_date", keep="last")
        values = pd.Series(frame["net_assets_yi"].to_numpy(), index=pd.DatetimeIndex(frame["known_date"]))
        if len(values):
            values_by_symbol[symbol] = values.reindex(values.index.union(dates)).sort_index().ffill().reindex(dates)
    return pd.DataFrame(values_by_symbol, index=dates, columns=symbols)


def winner(momentum, assets, observed, threshold):
    eligible = np.isfinite(momentum) & (momentum > 0) & np.isfinite(assets) & (assets > threshold) & observed
    choices = np.flatnonzero(eligible)
    if not len(choices):
        return -1, 0
    # Columns are sorted by code, giving a reproducible tie-break.
    return int(choices[np.argmax(momentum[choices])]), len(choices)


def simulate_weekly(panel, cfg, start, allowed=None):
    dates, symbols = panel["close"].index, panel["close"].columns
    opens = panel["open"].to_numpy()
    closes = panel["close"].to_numpy()
    raw_close = panel["raw_close"].to_numpy()
    momentum = panel["momentum"].to_numpy()
    assets = panel["assets"].to_numpy()
    tradable = panel["tradable"].to_numpy(dtype=bool)
    scope = np.ones(len(symbols), dtype=bool) if allowed is None else symbols.isin(allowed)
    observed = panel.get("signal_observed", panel["raw_close"].notna()).to_numpy(dtype=bool)
    trend = panel.get("trend_pass", pd.DataFrame(True, index=dates, columns=symbols)).to_numpy(dtype=bool)
    scheduled_rows = set(rebalance_rows(dates, start, cfg.get("rebalance_every_weeks", 1)))
    weekly_exit = cfg.get('weekly_exit_on_ineligible', False)
    review_rows = set(rebalance_rows(dates, start, 1)) if weekly_exit else scheduled_rows
    cash = float(cfg["initial_capital"])
    previous_equity = cash
    held, units = -1, 0.0
    cost_rate = (cfg["commission_bps"] + cfg["slippage_bps"]) / 10000
    daily, trades, decisions = [], [], []
    for row in range(start, len(dates)):
        date, signal_date = dates[row], dates[row - 1]
        scheduled = row in scheduled_rows
        fee, traded, blocked = 0.0, 0.0, False
        equity_open = cash + (units * opens[row, held] if held >= 0 else 0.0)
        if row in review_rows:
            eligible = (np.isfinite(momentum[row - 1]) & (momentum[row - 1] > 0) &
                        np.isfinite(assets[row - 1]) & (assets[row - 1] > cfg['minimum_net_assets_yi']) &
                        observed[row - 1] & trend[row - 1] & scope)
            if scheduled:
                selected, count = winner(momentum[row - 1], assets[row - 1],
                                         observed[row - 1] & trend[row - 1] & scope, cfg["minimum_net_assets_yi"])
                decision_reason = 'scheduled_selection'
            else:
                selected = held if held >= 0 and eligible[held] else -1
                count = int(eligible.sum())
                decision_reason = 'eligibility_exit' if held >= 0 and selected < 0 else 'weekly_hold'
            old = held
            blocked = ((held >= 0 and selected != held and not tradable[row, held]) or
                       (selected >= 0 and selected != held and not tradable[row, selected]))
            if selected != held and not blocked:
                if held >= 0:
                    notional = units * opens[row, held]
                    cost = notional * cost_rate
                    cash += notional - cost
                    fee += cost
                    traded += notional
                    trades.append({"date": date, "signal_date": signal_date, "symbol": symbols[held],
                                   "side": "SELL", "adjusted_price": opens[row, held],
                                   "units_delta": -units, "notional": notional, "cost": cost})
                    units, held = 0.0, -1
                if selected >= 0:
                    notional = cash / (1 + cost_rate)
                    cost = notional * cost_rate
                    units = notional / opens[row, selected]
                    cash -= notional + cost
                    if abs(cash) < 1e-7:
                        cash = 0.0
                    held = selected
                    fee += cost
                    traded += notional
                    trades.append({"date": date, "signal_date": signal_date, "symbol": symbols[held],
                                   "side": "BUY", "adjusted_price": opens[row, held],
                                   "units_delta": units, "notional": notional, "cost": cost})
            decisions.append({"date": date, "signal_date": signal_date, "eligible_count": count,
                              "selected": symbols[selected] if selected >= 0 else "CASH",
                              "momentum": momentum[row - 1, selected] if selected >= 0 else np.nan,
                              "lagged_assets_yi": assets[row - 1, selected] if selected >= 0 else np.nan,
                              "previous_holding": symbols[old] if old >= 0 else "CASH", "blocked": blocked,
                              "actual_holding": symbols[held] if held >= 0 else "CASH"})
            if weekly_exit:
                decisions[-1].update(is_selection_day=scheduled, decision_reason=decision_reason)
            if "weekly_close" in panel:
                week_date = panel["weekly_close"].index[panel["weekly_close"].index <= signal_date][-1]
                decisions[-1]["weekly_signal_date"] = week_date
                if "weekly_ma" in panel and selected >= 0:
                    decisions[-1]["weekly_signal_close"] = panel["weekly_close"].loc[week_date, symbols[selected]]
                    decisions[-1]["weekly_signal_ma"] = panel["weekly_ma"].loc[week_date, symbols[selected]]
        close_value = units * closes[row, held] if held >= 0 else 0.0
        equity = cash + close_value
        if not np.isfinite(equity) or equity <= 0 or cash < -1e-6:
            raise ArithmeticError(f"Invalid valuation {date}")
        daily.append({"date": date, "equity": equity, "nav": equity / cfg["initial_capital"],
                      "return": equity / previous_equity - 1, "cash": cash, "cash_weight": cash / equity,
                      "exposure": close_value / equity, "cost": fee, "turnover": traded / equity_open,
                      "holding": symbols[held] if held >= 0 else "CASH", "adjusted_units": units,
                      "held_price_missing": held >= 0 and not np.isfinite(raw_close[row, held]),
                      "rebalance_day": scheduled})
        previous_equity = equity
    return (pd.DataFrame(daily).set_index("date"),
            pd.DataFrame(trades, columns=["date", "signal_date", "symbol", "side", "adjusted_price", "units_delta", "notional", "cost"]),
            pd.DataFrame(decisions))


def load_market(cfg, end):
    manifest = json.loads((DATA / "manifest.json").read_text(encoding="utf-8"))
    universe = pd.read_csv(DATA / "universe.csv", dtype={"code": str})
    universe = universe.loc[universe["bars"].notna()].sort_values("code")
    history = pd.read_csv(DATA / "scale_history.csv", parse_dates=["report_date"])
    if not (DATA / "prices" / "sh510300.csv").exists():
        raise ValueError("CSI 300 ETF required for the common calendar and benchmark")
    benchmark = validate_frame(pd.read_csv(DATA / "prices" / "sh510300.csv"), "sh510300").loc[:end]
    dates = benchmark.index
    opens, raw_close, tradable = {}, {}, {}
    gaps = []
    for _, record in universe.iterrows():
        symbol = record["symbol"]
        path = DATA / "prices" / f"{symbol}.csv"
        if hashlib.sha256(path.read_bytes()).hexdigest() != record["sha256"]:
            raise ValueError(f"{symbol}: price snapshot hash differs")
        frame = validate_frame(pd.read_csv(path), symbol).loc[:end]
        aligned = frame.reindex(dates)
        raw_close[symbol] = aligned["close"]
        known = aligned["close"].ffill()
        opens[symbol] = aligned["open"].where(aligned["open"].notna(), known.shift(1))
        tradable[symbol] = aligned["open"].notna() & aligned["volume"].gt(0)
        for date in pd.DatetimeIndex(cfg.get("nontradable_at_open", {}).get(symbol, [])):
            if date in dates:
                tradable[symbol].loc[date] = False
                opens[symbol].loc[date] = known.shift(1).loc[date]
        missing = dates[(dates >= frame.index[0]) & (dates <= frame.index[-1])].difference(frame.index)
        if len(missing):
            gaps.append({"symbol": symbol, "missing_count": len(missing), "dates": "|".join(str(date.date()) for date in missing)})
    if not raw_close:
        raise ValueError("No usable ETF universe")
    panel = {"open": pd.DataFrame(opens), "raw_close": pd.DataFrame(raw_close),
             "tradable": pd.DataFrame(tradable)}
    panel["close"] = panel["raw_close"].ffill()
    if cfg.get("momentum_frequency", "daily") == "weekly":
        panel.update(weekly_signal_panel(panel["raw_close"], cfg["momentum_window"], cfg.get("trend_ma_weeks"),
                                         last_week_complete=cfg.get("last_week_complete", False)))
    else:
        panel["momentum"] = momentum_panel(panel["raw_close"], cfg["momentum_window"])
    panel["assets"] = scale_panel(history, dates, panel["close"].columns, cfg["scale_availability_lag_days"])
    return panel, universe, manifest, benchmark, pd.DataFrame(gaps, columns=["symbol", "missing_count", "dates"])


def audit(panel, cfg, daily, trades, decisions, allowed=None):
    rate = (cfg["commission_bps"] + cfg["slippage_bps"]) / 10000
    cash = cfg["initial_capital"]
    units = pd.Series(0.0, index=panel["close"].columns)
    fills = {date: frame for date, frame in trades.groupby("date")}
    errors = []
    # Independent clock: enumerate the nonempty weeks and take every Nth one.
    calendar = pd.Series(daily.index, index=daily.index).groupby(daily.index.to_period("W-FRI")).first()
    expected_dates = pd.DatetimeIndex(calendar.iloc[::cfg.get("rebalance_every_weeks", 1)])
    weekly_exit = cfg.get('weekly_exit_on_ineligible', False)
    review_dates = pd.DatetimeIndex(calendar) if weekly_exit else expected_dates
    assert list(decisions["date"]) == list(review_dates)
    assert set(trades["date"]).issubset(review_dates)
    previous_holdings = {}
    for date, row in daily.iterrows():
        before_active = units.abs() > 1e-7
        previous_holdings[date] = units.index[before_active][0] if before_active.any() else 'CASH'
        for _, fill in fills.get(date, pd.DataFrame()).iterrows():
            assert fill["signal_date"] < date
            position = panel["close"].index.get_loc(date)
            assert fill["signal_date"] == panel["close"].index[position - 1]
            assert panel["tradable"].loc[date, fill["symbol"]]
            assert np.isclose(fill["adjusted_price"], panel["open"].loc[date, fill["symbol"]])
            assert np.isclose(abs(fill["units_delta"]) * fill["adjusted_price"], fill["notional"])
            assert np.isclose(fill["cost"], fill["notional"] * rate)
            cash -= (1 if fill["side"] == "BUY" else -1) * fill["notional"] + fill["cost"]
            units[fill["symbol"]] += fill["units_delta"]
        active = units.abs() > 1e-7
        assert active.sum() <= 1
        equity = cash + (units.loc[active] * panel["close"].loc[date, active]).sum()
        errors.append(abs(equity - row["equity"]))
        assert cash >= -1e-5
        assert abs(cash - row["cash"]) < 1e-5
        active_after = units.abs() > 1e-7
        assert row['holding'] == (units.index[active_after][0] if active_after.any() else 'CASH')
    assert max(errors) < 1e-4
    assert np.isclose(trades["cost"].sum(), daily["cost"].sum(), atol=1e-5)
    for _, row in decisions.iterrows():
        signal_date = row["signal_date"]
        momentum = panel["momentum"].loc[signal_date]
        assets = panel["assets"].loc[signal_date]
        eligible = momentum.notna() & momentum.gt(0) & assets.gt(cfg["minimum_net_assets_yi"])
        eligible &= panel.get("signal_observed", panel["raw_close"].notna()).loc[signal_date]
        if "trend_pass" in panel:
            eligible &= panel["trend_pass"].loc[signal_date]
        if allowed is not None:
            eligible &= eligible.index.isin(allowed)
        ranked = momentum.loc[eligible].sort_values(ascending=False, kind="stable")
        if weekly_exit and row['date'] not in expected_dates:
            previous = previous_holdings[row['date']]
            expected = previous if previous != 'CASH' and bool(eligible[previous]) else 'CASH'
            assert not row.is_selection_day
            assert row.previous_holding == previous
            assert row.decision_reason == ('eligibility_exit' if previous != 'CASH' and expected == 'CASH' else 'weekly_hold')
            assert row['selected'] == expected
            assert all(fill.side == 'SELL' for _, fill in fills.get(row['date'], pd.DataFrame()).iterrows())
        else:
            assert row["selected"] == (ranked.index[0] if len(ranked) else "CASH")
            if weekly_exit:
                assert row.is_selection_day and row.decision_reason == 'scheduled_selection'
        assert row["eligible_count"] == len(ranked)
        if row["selected"] != "CASH":
            assert row["momentum"] > 0 and row["lagged_assets_yi"] > cfg["minimum_net_assets_yi"]
            assert np.isclose(row["momentum"], momentum[row["selected"]])
            assert np.isclose(row["lagged_assets_yi"], assets[row["selected"]])
            if cfg.get("momentum_frequency", "daily") == "weekly":
                history = panel["raw_close"].loc[:signal_date, row["selected"]].dropna()
                weekly = history.groupby(history.index.to_period("W-FRI")).last()
                window = cfg["momentum_window"]
                assert len(weekly) >= window + 1
                assert np.isclose(row["momentum"], weekly.iloc[-1] / weekly.iloc[-1 - window] - 1)
                if cfg.get("trend_ma_weeks"):
                    ma_weeks = cfg["trend_ma_weeks"]
                    assert len(weekly) >= ma_weeks
                    independent_ma = weekly.iloc[-ma_weeks:].mean()
                    assert weekly.iloc[-1] > independent_ma
                    assert np.isclose(row["weekly_signal_close"], weekly.iloc[-1])
                    assert np.isclose(row["weekly_signal_ma"], independent_ma)
        if "trend_pass" in panel:
            # Rebuild every candidate's trend gate without using the stored MA panel.
            history = panel["raw_close"].loc[:signal_date]
            weeks = history.groupby(history.index.to_period("W-FRI")).last()
            independent_trend = pd.Series(False, index=weeks.columns)
            for symbol in weeks:
                observed_weeks = weeks[symbol].dropna()
                if pd.notna(weeks[symbol].iloc[-1]) and len(observed_weeks) >= cfg['trend_ma_weeks']:
                    independent_trend[symbol] = observed_weeks.iloc[-1] > observed_weeks.iloc[-cfg['trend_ma_weeks']:].mean()
            pd.testing.assert_series_equal(independent_trend, panel['trend_pass'].loc[signal_date], check_names=False)
    return {"passed": True, "max_equity_error_cny": max(errors), "days": len(daily),
            "fills": len(trades), "weekly_decisions": len(decisions),
            "blocked_decisions": int(decisions["blocked"].sum()),
            "held_missing_price_days": int(daily["held_price_missing"].sum())}


def buy_hold(benchmark, dates, cfg):
    frame = benchmark.loc[dates]
    cost_rate = (cfg["commission_bps"] + cfg["slippage_bps"]) / 10000
    notional = cfg["initial_capital"] / (1 + cost_rate)
    equity = notional / frame["open"].iloc[0] * frame["close"]
    result = pd.DataFrame({"equity": equity, "nav": equity / cfg["initial_capital"], "cash": 0.0,
                           "cash_weight": 0.0, "exposure": 1.0, "cost": 0.0, "turnover": 0.0}, index=dates)
    result["return"] = equity.pct_change(fill_method=None)
    result.loc[dates[0], "return"] = equity.iloc[0] / cfg["initial_capital"] - 1
    result.loc[dates[0], "cost"] = notional * cost_rate
    result.loc[dates[0], "turnover"] = notional / cfg["initial_capital"]
    return result


def save(frame, path, index=True):
    frame.to_csv(path, index=index, encoding="utf-8-sig", date_format="%Y-%m-%d")


def render(results, summary, annual, costs, rankings, universe, metadata):
    cfg = metadata["config"]
    weekly_mode = cfg.get("momentum_frequency", "daily") == "weekly"
    every = cfg.get("rebalance_every_weeks", 1)
    momentum_label = f"{cfg['momentum_window']}周" if weekly_mode else "13周"
    clock_label = f"每{every}根有效周线" if weekly_mode else "每周"
    momentum_rule = (f"按各ETF真实日线聚合周线，以周内最后一条有效收盘为周收盘。涨幅＝最新已完成周收盘／{cfg['momentum_window']}根有效周线前的周收盘−1。"
                     f"至少需要{cfg['momentum_window'] + 1}根有效周线；整周无报价不生成假周线，未确认完成的末周不参与信号。") if weekly_mode else "13周按65个有效日线近似，涨幅＝复权收盘／65个有效日线前复权收盘−1。"
    clock_rule = (f"回测起点{metadata['start']}从现金首次建仓，之后每累计{every}根有交易的市场周线，在下一周首个交易日开盘调仓。整周休市不计数；这不是自然月调仓。") if weekly_mode else "每周首个交易日开盘调仓。"
    signal_description = "已完成周线" if weekly_mode else "前一交易日收盘信号"
    required_history = f"至少拥有{cfg['momentum_window'] + 1}根有效周线、可计算{momentum_label}涨幅" if weekly_mode else "至少拥有66个有效日线、可计算65日涨幅"
    fixed = cfg.get('fixed_pool', False)
    ma_weeks = cfg.get('trend_ma_weeks')
    pool_label = '指定四ETF池' if fixed else '全ETF池'
    trend_label = f' · 周收盘高于{ma_weeks}周均线' if ma_weeks else ''
    trend_rule = (f"还须最新已完成周收盘严格高于{ma_weeks}根有效周收盘的算术平均（含信号周），不足{ma_weeks}根有效周线不合格。" if ma_weeks else '')
    if ma_weeks:
        required_history += f'，并拥有{ma_weeks}根有效周线以计算均线'
    labels = {"all_etf": f"{pool_label}：{clock_label}最强一只{trend_label}", "five_etf": "原五ETF池：同规则", "buy_hold_300": "沪深300ETF买入持有", "previous_13w": "此前13周涨幅、每周调仓", 'without_ma':'同四ETF池：不加40周均线过滤'}
    fig, axes = plt.subplots(2, 1, figsize=(12, 8), sharex=True)
    for key, frame in results.items():
        label = {"all_etf": f"{'Selected 4 ETFs' if fixed else 'Broad ETF universe'}: every {every} weeks" + (f", close > MA{ma_weeks}" if ma_weeks else ''), "five_etf": "Original 5 ETFs: same rule", "buy_hold_300": "CSI 300 ETF buy & hold", "previous_13w": "Previous: 65-day momentum, weekly rebalance", 'without_ma':'Same 4 ETFs: without MA filter'}[key]
        nav = frame["nav"]
        axes[0].plot(nav.index, nav, label=label)
        axes[1].plot(nav.index, nav / nav.cummax().clip(lower=1) - 1)
    axes[0].legend()
    axes[0].set_ylabel("Net asset value")
    axes[1].set_ylabel("Drawdown")
    for ax in axes:
        ax.grid(alpha=0.2)
    window_label = f"{cfg['momentum_window']}-week" if weekly_mode else "65-day"
    fig.suptitle(f"Full-investment top-1 ETF | {window_label} momentum | every {every} observed weeks" + (f" | MA{ma_weeks} filter" if ma_weeks else ''))
    fig.tight_layout()
    fig.savefig(OUT / "equity_drawdown.png", dpi=160)
    plt.close(fig)
    def table(frame):
        return frame.to_html(index=False, escape=True, border=0)
    display = summary.reset_index().rename(columns={"variant": "策略"})
    display["策略"] = display["策略"].map(labels)
    display = display[["策略", "total_return", "annual_return", "max_drawdown", "sharpe_zero_rf", "cash_day_ratio"]]
    display["max_drawdown"] = display["max_drawdown"].abs()
    for col in ["total_return", "annual_return", "max_drawdown", "cash_day_ratio"]:
        display[col] = display[col].map(lambda x: f"{x:.2%}")
    display["sharpe_zero_rf"] = display["sharpe_zero_rf"].map(lambda x: f"{x:.2f}")
    display.rename(columns={"total_return": "累计收益", "annual_return": "年化收益", "max_drawdown": "最大回撤",
                            "sharpe_zero_rf": "夏普(无风险利率0)", "cash_day_ratio": "空仓日占比"}, inplace=True)
    yr = annual.pivot(index="year", columns="variant", values="return").rename(columns=labels).reset_index()
    for col in yr.columns[1:]:
        yr[col] = yr[col].map(lambda x: f"{x:.2%}")
    cs = costs[["cost_bps", "annual_return", "max_drawdown"]].copy()
    for col in ["annual_return", "max_drawdown"]:
        cs[col] = cs[col].map(lambda x: f"{x:.2%}")
    cs.rename(columns={"cost_bps": "单边成本bp", "annual_return": "年化收益", "max_drawdown": "最大回撤"}, inplace=True)
    rank = rankings.head(15)[["code", "name", "momentum", "assets_yi", "eligible"]].copy()
    if ma_weeks:
        rank['weekly_close'] = rankings.head(15)['weekly_close'].map(lambda x: f'{x:.4f}')
        rank['weekly_ma'] = rankings.head(15)['weekly_ma'].map(lambda x: f'{x:.4f}')
    rank["momentum"] = rank["momentum"].map(lambda x: f"{x:.2%}")
    rank["assets_yi"] = rank["assets_yi"].map(lambda x: f"{x:.2f}")
    rank["eligible"] = rank["eligible"].map({True: "是", False: "否"})
    rank.rename(columns={"code": "ETF", "name": "名称", "momentum": f"{momentum_label}涨幅", "assets_yi": "已允许使用的净资产(亿元)", "eligible": "合格"}, inplace=True)
    rank.rename(columns={'weekly_close':'复权周收盘', 'weekly_ma':f'{ma_weeks}周均线'}, inplace=True)
    main = summary.loc["all_etf"]
    universe_min, universe_max = metadata["weekly_eligible_min"], metadata["weekly_eligible_max"]
    pool_description = (f"固定使用用户指定的四只ETF，不再扫描全市场纯A股ETF。纳斯达克100使用境内上市的国泰513100，信号、成交均采用其人民币场内价格，不使用美股指数替代。<div class='scroll'>{table(universe[['code','name','full_name']].rename(columns={'code':'ETF代码','name':'名称','full_name':'基金全称'}))}</div>" if fixed else f"公开基金注册表初筛出{metadata['registry_candidates']}只股票指数ETF候选；历史净资产曾超过10亿元且核对全称属于纯A股范围的有{metadata['historically_over_threshold']}只。")
    scope_description = ('四只ETF分别核对基金全称；纳斯达克100为用户明确指定的跨境QDII标的。用户基于高波动与攻击性的选池逻辑主动指定这四只ETF，本次回测用于检验该投资思路，不对选池动机作事后归因。' if fixed else f"使用公共注册表的当前分类与简称初筛，并逐只核对历史上达到门槛ETF的基金全称，剔除跨境/混合市场、债券、货币、商品及联接基金。全称核对共排除{metadata.get('market_scope_exclusions', 0)}个候选。注册表对已清盘基金的覆盖未确认，仍可能存在幸存者偏差或分类变更偏差。")
    product_sources = ' · '.join(f'<a href="{html.escape(url)}">{code}基金产品</a>' for code, url in metadata.get('fund_product_sources', {}).items())
    fixed_note = ('纳斯达克ETF的汇率变化与场内溢折价体现在市场价格中；未另外模拟QDII申购额度和溢价风控。' if fixed else '')
    if fixed:
        fixed_note += f"持仓报价缺失的1天为513100在2022-01-13拆分停牌，当天按前收盘估值，不生成成交或假日线；复权拆分因子于2022-01-14恢复交易时生效，见<a href='{html.escape(metadata.get('nasdaq_split_source', 'https://www.sse.com.cn/disclosure/fund/announcement/c/new/2022-01-04/513100_20220104_1_0U96WMU8.pdf'))}'>基金管理人拆分及停牌公告</a>。"
    comparison_note = ('报告额外比较同四ETF池去掉均线过滤的结果，其他规则与费用一致。' if fixed else '原五ETF池对照使用同样的规模门槛和交易规则。')
    source_correction = ('' if fixed else f'510500于2022-08-26日终拆分，场内价格调整因子从下一交易日2022-08-29启用；依据<a href="{html.escape(metadata.get("split_correction_source", ""))}">基金管理人拆分公告</a>修正供应商提前标记的记录，并与留存腾讯价格交叉核对。')
    source_extra_links = ('' if fixed else '<a href="excluded_market_scope.csv">标的范围排除记录</a> · <a href="source_crosscheck.csv">原五ETF跨来源核对</a> · ')
    weekly_links = ('<a href="weekly_closes.csv">有效周收盘</a> · <a href="weekly_momentum.csv">周线涨幅</a> · ' if weekly_mode else '')
    if ma_weeks:
        weekly_links += '<a href="weekly_ma.csv">40周均线</a> · '
    eligibility_rule = '且周收盘高于40周均线' if ma_weeks else ''
    diagnosis = ''
    if fixed and 'without_ma' in results:
        main_daily, other_daily = results['all_etf'], results['without_ma']
        review_year = main_daily.index[-1].year
        current = main_daily.loc[str(review_year)]
        peak = main_daily['nav'].cummax().clip(lower=1)
        drawdowns = main_daily['nav'] / peak - 1
        trough_date = drawdowns.loc[str(review_year)].idxmin()
        peak_date = main_daily.loc[:trough_date, 'nav'].idxmax()
        interval = main_daily.loc[peak_date:trough_date]
        held_codes = interval['holding'].unique()
        same_path = main_daily.loc[str(review_year), 'holding'].equals(other_daily.loc[str(review_year), 'holding'])
        diagnosis = f'''<section><h2>均线过滤的作用与{review_year}年回撤</h2>
<p>均线过滤增加了空仓，但不能仅凭最终最大回撤相同就判定其无效。请结合年度收益与不同下跌区间比较作用；40周均线是趋势条件，不是从价格高点回撤一定比例就卖出的规则。</p>
<p>{review_year}年最深回撤从{peak_date.date()}的净值{main_daily.loc[peak_date,'nav']:.4f}，跌至{trough_date.date()}的{main_daily.loc[trough_date,'nav']:.4f}，幅度为{abs(drawdowns.loc[trough_date]):.2%}。
该区间持仓为{html.escape('、'.join(held_codes))}，连续全仓持有。{'两版在该年度每天持仓完全相同，因此该次下跌中均线过滤没有改变风险暴露。' if same_path else '两版年度持仓存在差异，可结合决策与成交记录比较。'}</p>
<p>26周动量和40周均线衡量较长趋势，价格从高点下跌时仍可能同时满足入选条件。现行规则仅每4根有效周线检查一次；期间不因日内或周内跌破均线而提前退出。全仓持有一只ETF时，其价格回撤会直接传递至账户。</p>
<p><a href="drawdown_review.html">查看回撤起止、关键周线条件、年度对比与相关性核对</a></p></section>'''
    report = f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>A股ETF动量轮动</title><style>body{{background:#f3f5f9;color:#172033;font:15px/1.7 "Microsoft YaHei",sans-serif;margin:0}}
main{{max-width:1180px;margin:36px auto;padding:0 24px}}section{{background:white;border-radius:14px;padding:24px;margin:18px 0}}
h1{{font-size:30px}}h2{{font-size:20px;margin-top:0}}table{{border-collapse:collapse;width:100%;white-space:nowrap}}
th,td{{padding:9px;border-bottom:1px solid #e7ebf2;text-align:right}}th:first-child,td:first-child{{text-align:left}}.scroll{{overflow:auto}}
th{{background:#f7f9fc}}img{{width:100%}}a{{color:#285fca}}.note{{border-left:4px solid #477aee;padding-left:14px}}</style>
<main><h1>{'四ETF轮动' if fixed else 'A股ETF'}：{clock_label}比较{momentum_label}涨幅</h1>
<p>历史净资产&gt;10亿元 · 涨幅为正{trend_label} · 最强一只全仓 · 均不合格则现金 · 下一周开盘执行</p>
<section><h2>回测结果</h2><p>{metadata['start']}—{metadata['end']}，共{len(results['all_etf'])}个交易日。
主策略年化收益 {main['annual_return']:.2%}，最大回撤 {abs(main['max_drawdown']):.2%}。年化按每年{metadata['config']['annualization']}个交易日计算。</p>
<div class="scroll">{table(display)}</div><img src="equity_drawdown.png" alt="ETF池动量轮动净值与回撤"></section>
<section><h2>规模与标的口径</h2><div>{pool_description}</div><p>取得可用行情的有{len(universe)}只。每次计划调仓的实际合格池为{universe_min}—{universe_max}只，随历史规模、上市时长、动量与均线条件变化。</p>
<p class="note">规模是过去报告期末净资产，单位亿元，严格&gt;10；不是成交额、份额数或当前市值。
报告期末数据统一延后100个自然日才允许用于筛选，因为供应商没有完整的逐项公告时间。
该滞后是保守近似，仍不等同完整的公告时点数据。</p>
<p>{scope_description}
曾经规模大、后来变小的ETF仍保留历史资格；{required_history}，并满足当时规模才可参选。
</p>
<p>规模/行情下载失败共{metadata['failure_count']}项，逐项保留在下载记录中，不使用模拟数据补齐。</p></section>
<section><h2>交易规则</h2><ol>
<li>{momentum_rule}{trend_rule}</li>
<li>{clock_rule}使用{signal_description}和前一个交易日收盘时可知的规模数据。在历史净资产&gt;10亿元、{momentum_label}涨幅&gt;0{eligibility_rule}的ETF中，
选择涨幅最高的一只，全仓买入；同分按ETF代码排序，没有合格标的则持有现金。</li>
<li>仅在上述调仓日决策；两次调仓之间即使动量转负也继续持有至下一次调仓。仍是同一只则不重复买卖。</li>
<li>旧仓承受隔夜涨跌后卖出，再扣费全仓买入新仓。每笔买卖佣金3bp＋滑点2bp，现金利息为0。
首个回测交易日从现金开始建仓。</li>
<li>价格缺失按前次已知收盘估值，禁止以填充价格成交。如果旧仓不能卖出或新仓不能买入，本次维持原持仓/现金，
不改买次强者，等待下一次计划调仓。已知159915在2021-02-08与2021-02-09开盘不可交易。</li>
</ol><p>{comparison_note}</p></section>
<section><h2>年度表现</h2><div class="scroll">{table(yr)}</div><p>2026年为截至末日的部分年度，未外推全年。</p></section>
{diagnosis}
<section><h2>交易成本敏感性</h2><div class="scroll">{table(cs)}</div></section>
<section><h2>{metadata['ranking_asof']}信号排名</h2><div class="scroll">{table(rank)}</div>
<p>这是截至该日已确认完成的信号排名，不表示今天必须换仓。下次计划调仓需重新计算届时数据。
末次实际调仓日期：{metadata['last_rebalance_date']}。实际回测末日持仓：
{html.escape(metadata['last_holding_name'])}。</p></section>
<section><h2>核对与局限</h2><p>从成交日志独立重建每日现金、单位和净值，核对单只持仓、费用与规模/正动量条件。
主策略共{metadata['audit']['fills']}笔成交，{metadata['audit']['blocked_decisions']}次调仓决策因行情不可成交而冻结，
持仓期间缺失报价{metadata['audit']['held_missing_price_days']}个交易日。净值重建最大误差{metadata['audit']['max_equity_error_cny']:.8f}元。</p>
<p>行情来源：{html.escape(metadata.get('price_provider', 'unknown'))}，复权口径：{html.escape(metadata.get('adjustment', 'unknown'))}。
原始日线和历史复权因子均保存，按各日期已生效的因子调整价格，不向指标插入停牌报价。
{source_correction}
共剔除{metadata['nontrading_bar_count']}条成交量为零的日线，日期在ETF名单中保留；它们不参与动量窗口或成交。
使用连续调整后单位；未模拟100份交易单位、最低佣金、涨跌停、真实开盘冲击与所有盘中停牌。
{fixed_note}公众数据的复权与规模仍需独立数据商核对。历史回测不证明未来有效。</p>
<p><a href="summary.csv">指标</a> · <a href="all_etf_daily.csv">每日净值与持仓</a> · <a href="all_etf_trades.csv">成交</a> ·
<a href="weekly_decisions.csv">调仓选ETF记录</a> · <a href="ranking.csv">完整排名</a> · <a href="universe.csv">ETF名单</a> ·
<a href="annual_returns.csv">年度收益</a> · <a href="data_gaps.csv">行情缺失</a> · <a href="download_failures.csv">下载失败</a> ·
{source_extra_links}
{weekly_links}
<a href="metadata.json">数据与核对信息</a></p>
<p>来源：<a href="https://fund.eastmoney.com/js/fundcode_search.js">天天基金公共注册表</a>、
<a href="https://fundf10.eastmoney.com/510300.html">基金历史规模页面</a>、
<a href="https://finance.sina.com.cn/fund/quotes/510300/bc.shtml">新浪公开ETF日线与历史复权因子</a>。
{product_sources}。复现：<code>{html.escape(metadata['reproduce_command'])}</code></p>
<p><a href="../report.html">原五指数通道报告</a> · <a href="../optimization.html">通道参数优化研究</a></p></section></main></html>'''
    (OUT / "report.html").write_text(report, encoding="utf-8")


def main():
    global OUT, DATA
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--end", default=completed_end())
    parser.add_argument("--config", default="etf_weekly_config.json")
    parser.add_argument("--output-dir", default="output/etf_weekly")
    args = parser.parse_args()
    if pd.Timestamp(args.end) > pd.Timestamp(completed_end()):
        raise ValueError("Do not use an incomplete daily bar")
    cfg = json.loads((ROOT / args.config).read_text(encoding="utf-8"))
    DATA = ROOT / cfg.get("data_dir", "data/etf_weekly")
    OUT = ROOT / args.output_dir
    panel, universe, manifest, benchmark, gaps = load_market(cfg, args.end)
    OUT.mkdir(parents=True, exist_ok=True)
    start = int(panel["close"].index.searchsorted(pd.Timestamp(cfg["backtest_start"])))
    if start < 1 or start >= len(panel["close"]):
        raise ValueError("Invalid evaluation start")
    full, trades, decisions = simulate_weekly(panel, cfg, start)
    checked = audit(panel, cfg, full, trades, decisions)
    five_symbols = ["sh510300", "sz159915", "sz159967", "sh510500", "sh510050"]
    if not cfg.get('fixed_pool') and not set(five_symbols).issubset(panel["close"].columns):
        raise ValueError("Original five ETF comparison requires all five price histories")
    results = {"all_etf": full, "buy_hold_300": buy_hold(benchmark, full.index, cfg)}
    if not cfg.get('fixed_pool'):
        five, five_trades, five_decisions = simulate_weekly(panel, cfg, start, allowed=five_symbols)
        audit(panel, cfg, five, five_trades, five_decisions, allowed=five_symbols)
        results['five_etf'] = five
        save(five_trades, OUT / 'five_etf_trades.csv', index=False)
    if cfg.get('compare_without_ma'):
        unfiltered_cfg = {**cfg, 'trend_ma_weeks': None}
        unfiltered_panel = {key: value for key, value in panel.items() if key not in ['trend_pass', 'trend_ma', 'weekly_ma']}
        unfiltered, unfiltered_trades, unfiltered_decisions = simulate_weekly(unfiltered_panel, unfiltered_cfg, start)
        audit(unfiltered_panel, unfiltered_cfg, unfiltered, unfiltered_trades, unfiltered_decisions)
        results['without_ma'] = unfiltered
        save(unfiltered_trades, OUT / 'without_ma_trades.csv', index=False)
        save(unfiltered_decisions, OUT / 'without_ma_decisions.csv', index=False)
    if cfg.get("compare_previous_13w", False):
        prior_cfg = {**cfg, "momentum_frequency": "daily", "momentum_window": 65, "rebalance_every_weeks": 1}
        prior_panel = {key: value for key, value in panel.items() if key not in ["signal_observed", "weekly_close", "weekly_momentum"]}
        prior_panel["momentum"] = momentum_panel(panel["raw_close"], 65)
        prior, prior_trades, prior_decisions = simulate_weekly(prior_panel, prior_cfg, start)
        audit(prior_panel, prior_cfg, prior, prior_trades, prior_decisions)
        results["previous_13w"] = prior
        save(prior_trades, OUT / "previous_13w_trades.csv", index=False)
        save(prior_decisions, OUT / "previous_13w_decisions.csv", index=False)
    summary = pd.DataFrame({key: metrics(frame, cfg['annualization']) for key, frame in results.items()}).T
    summary.index.name = "variant"
    save(summary, OUT / "summary.csv")
    for key, frame in results.items():
        save(frame, OUT / f"{key}_daily.csv")
    save(trades, OUT / "all_etf_trades.csv", index=False)
    save(decisions, OUT / "weekly_decisions.csv", index=False)
    annual = pd.DataFrame([{"variant": key, "year": int(year), "return": float((1 + part["return"]).prod() - 1), "days": len(part)}
                           for key, frame in results.items() for year, part in frame.groupby(frame.index.year)])
    save(annual, OUT / "annual_returns.csv", index=False)
    costs = []
    for cost in [0, 5, 10, 20]:
        scenario = {**cfg, "commission_bps": cost, "slippage_bps": 0}
        frame, _, _ = simulate_weekly(panel, scenario, start)
        costs.append({"cost_bps": cost, **metrics(frame, cfg['annualization'])})
    costs = pd.DataFrame(costs)
    save(costs, OUT / "costs.csv", index=False)
    last = panel["close"].index[-1]
    ranking_date = panel["weekly_close"].index[-1] if "weekly_close" in panel else last
    ranks = pd.DataFrame({"symbol": panel["momentum"].columns, "momentum": panel["momentum"].loc[ranking_date].to_numpy(),
                          "assets_yi": panel["assets"].loc[ranking_date].to_numpy(),
                          "observed": panel.get("signal_observed", panel["raw_close"].notna()).loc[ranking_date].to_numpy()})
    ranks["eligible"] = (ranks["momentum"] > 0) & (ranks["assets_yi"] > cfg["minimum_net_assets_yi"]) & ranks["observed"]
    if 'weekly_ma' in panel:
        ranks['weekly_close'] = panel['weekly_close'].loc[ranking_date].to_numpy()
        ranks['weekly_ma'] = panel['weekly_ma'].loc[ranking_date].to_numpy()
        ranks['above_ma'] = ranks['weekly_close'] > ranks['weekly_ma']
        ranks['eligible'] &= ranks['above_ma']
    ranks = ranks.merge(universe[["symbol", "code", "name"]], on="symbol").sort_values(["eligible", "momentum", "code"], ascending=[False, False, True])
    save(ranks, OUT / "ranking.csv", index=False)
    save(universe, OUT / "universe.csv", index=False)
    save(gaps, OUT / "data_gaps.csv", index=False)
    if "weekly_close" in panel:
        save(panel["weekly_close"], OUT / "weekly_closes.csv")
        save(panel["weekly_momentum"], OUT / "weekly_momentum.csv")
        if 'weekly_ma' in panel:
            save(panel['weekly_ma'], OUT / 'weekly_ma.csv')
    failures = pd.read_csv(DATA / "download_failures.csv")
    save(failures, OUT / "download_failures.csv", index=False)
    for filename in ["excluded_market_scope.csv", "source_crosscheck.csv"]:
        path = DATA / filename
        if path.exists():
            (OUT / filename).write_bytes(path.read_bytes())
    names = dict(zip(universe["symbol"], universe["name"]))
    last_holding = full["holding"].iloc[-1]
    metadata = {**manifest, "config": cfg, "start": str(full.index[0].date()), "end": str(last.date()),
                "audit": checked, "failure_count": len(failures),
                "nontrading_bar_count": int(universe.get("nontrading_bar_count", pd.Series(dtype=float)).sum()),
                "weekly_eligible_min": int(decisions["eligible_count"].min()), "weekly_eligible_max": int(decisions["eligible_count"].max()),
                "last_holding": last_holding, "last_holding_name": names.get(last_holding, "现金"),
                "ranking_asof": str(ranking_date.date()), "last_rebalance_date": str(decisions['date'].iloc[-1].date()),
                "reproduce_command": f"python weekly_momentum.py --config {args.config} --output-dir {args.output_dir} --end {last.date()}",
                "scale_history_sha256": hashlib.sha256((DATA / "scale_history.csv").read_bytes()).hexdigest()}
    (OUT / "metadata.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
    if cfg.get('fixed_pool') and 'without_ma' in results:
        from diagnose_four import generate
        generate(OUT)
    render(results, summary, annual, costs, ranks, universe, metadata)
    for path in [ROOT / "output" / "report.html", ROOT / "output" / "optimization.html"]:
        if path.exists():
            content = path.read_text(encoding="utf-8")
            relative = OUT.relative_to(ROOT / "output").as_posix() + "/report.html"
            link_title = '四ETF轮动：26周动量与40周均线过滤' if cfg.get('fixed_pool') else f'纯A股ETF动量轮动：{cfg.get("rebalance_every_weeks", 1)}周调仓周期'
            content = content.replace(f'<a href="{relative}">纯A股ETF动量轮动：{cfg.get("rebalance_every_weeks", 1)}周调仓周期</a>', f'<a href="{relative}">{link_title}</a>')
            if f'href="{relative}"' not in content:
                content = content.replace("<main>", f'<main><p><a href="{relative}">{link_title}</a></p>', 1)
            path.write_text(content, encoding="utf-8")
    print(summary[["annual_return", "max_drawdown", "total_return", "sharpe_zero_rf"]].to_string())
    print(json.dumps(checked, indent=2))
    print(f"Report: {OUT / 'report.html'}")


if __name__ == "__main__":
    main()
