"""Public Tencent adjusted daily OHLC; preserve responses and provenance."""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timedelta, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

ENDPOINT = "https://web.ifzq.gtimg.cn/appstock/app/fqkline/get"


def completed_end() -> str:
    now = datetime.now(timezone(timedelta(hours=8)))
    # Avoid today's intraday/provisional bar. This is not an exchange calendar.
    if (now.hour, now.minute) < (15, 30):
        now -= timedelta(days=1)
    return now.date().isoformat()


def validate_frame(frame: pd.DataFrame, symbol: str) -> pd.DataFrame:
    required = ["date", "open", "close", "high", "low", "volume"]
    if not set(required).issubset(frame):
        raise ValueError(f"{symbol}: expected columns {required}")
    frame = frame[required].copy()
    frame["date"] = pd.to_datetime(frame["date"], errors="raise")
    if frame["date"].duplicated().any():
        raise ValueError(f"{symbol}: duplicate dates")
    for column in required[1:]:
        frame[column] = pd.to_numeric(frame[column], errors="raise")
    if not np.isfinite(frame[required[1:]].to_numpy()).all():
        raise ValueError(f"{symbol}: non-finite data")
    if (frame[["open", "close", "high", "low"]] <= 0).any().any():
        raise ValueError(f"{symbol}: non-positive prices")
    if (frame["volume"] <= 0).any():
        raise ValueError(f"{symbol}: non-trading/zero-volume bar")
    tolerance = 1e-8
    if ((frame["high"] + tolerance < frame[["open", "close", "low"]].max(axis=1)) |
            (frame["low"] - tolerance > frame[["open", "close", "high"]].min(axis=1))).any():
        raise ValueError(f"{symbol}: inconsistent OHLC")
    return frame.sort_values("date").set_index("date")


def fetch_all(config: dict, data_dir: Path, end: str) -> None:
    raw_dir = data_dir / "raw"
    raw_dir.mkdir(parents=True, exist_ok=True)
    session = requests.Session()
    session.mount("https://", HTTPAdapter(max_retries=Retry(
        total=3, backoff_factor=0.5, status_forcelist=[429, 500, 502, 503, 504]
    )))
    start = pd.Timestamp(config["data_start"])
    stop = pd.Timestamp(end)
    if start > stop:
        raise ValueError("data_start must not be after end")
    manifest = {
        "provider": "Tencent public fqkline", "endpoint": ENDPOINT,
        "adjustment": "hfq (provider houfuquan / 后复权)",
        "downloaded_at": datetime.now(timezone.utc).isoformat(),
        "requested_start": str(start.date()), "requested_end": end,
        "symbols": {},
    }
    for symbol in config["symbols"]:
        chunks = []
        requests_meta = []
        for year in range(start.year, stop.year + 1):
            # One-year windows plus a calendar-day overlap to validate consistency.
            left = max(start, pd.Timestamp(f"{year}-01-01") - pd.Timedelta(days=15))
            right = min(stop, pd.Timestamp(f"{year}-12-31"))
            param = f"{symbol},day,{left.date()},{right.date()},640,hfq"
            response = session.get(ENDPOINT, params={"param": param}, timeout=30)
            response.raise_for_status()
            payload = response.json()
            if payload.get("code") != 0:
                raise ValueError(f"{symbol}: provider error {payload.get('msg')}")
            block = payload.get("data", {}).get(symbol, {})
            # Never silently fall back to unadjusted prices.
            rows = block.get("hfqday", [])
            if not rows:
                raise ValueError(f"{symbol} {year}: no hfq data returned")
            path = raw_dir / f"{symbol}_{year}.json"
            path.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
            chunk = pd.DataFrame([row[:6] for row in rows], columns=
                                 ["date", "open", "close", "high", "low", "volume"])
            chunk = validate_frame(chunk, symbol)
            chunk = chunk.loc[(chunk.index >= left) & (chunk.index <= right)]
            if len(chunk) >= 640:
                raise ValueError(f"{symbol}: response may be truncated")
            if chunks:
                previous = pd.concat(chunks)
                overlap = previous.index.intersection(chunk.index)
                if len(overlap) and not np.allclose(
                    previous.loc[overlap, ["open", "close", "high", "low"]],
                    chunk.loc[overlap, ["open", "close", "high", "low"]],
                    atol=1e-8, rtol=1e-8,
                ):
                    raise ValueError(f"{symbol}: inconsistent adjusted prices across chunks")
            chunks.append(chunk)
            requests_meta.append({"param": param, "rows": len(chunk), "raw_file": str(path)})
        full = pd.concat(chunks)
        full = full[~full.index.duplicated(keep="last")].sort_index()
        full = full.loc[(full.index >= start) & (full.index <= stop)]
        target = data_dir / f"{symbol}.csv"
        full.to_csv(target, encoding="utf-8-sig", date_format="%Y-%m-%d")
        manifest["symbols"][symbol] = {
            "name": config["symbols"][symbol], "rows": len(full),
            "first": str(full.index[0].date()), "last": str(full.index[-1].date()),
            "sha256": hashlib.sha256(target.read_bytes()).hexdigest(),
            "requests": requests_meta,
        }
        print(f"{symbol}: {len(full)} bars, {full.index[0].date()} -> {full.index[-1].date()}", flush=True)
    (data_dir / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")


def load_panel(config: dict, data_dir: Path, end: str) -> dict[str, pd.DataFrame]:
    frames = {}
    manifest_path = data_dir / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8")) if manifest_path.exists() else None
    for symbol in config["symbols"]:
        path = data_dir / f"{symbol}.csv"
        if not path.exists():
            raise FileNotFoundError(f"Missing {path}; run python run.py --download")
        if manifest is not None:
            expected = manifest.get("symbols", {}).get(symbol, {}).get("sha256")
            actual = hashlib.sha256(path.read_bytes()).hexdigest()
            if expected != actual:
                raise ValueError(f"{symbol}: CSV hash differs from manifest; redownload a consistent snapshot")
        frames[symbol] = validate_frame(pd.read_csv(path), symbol).loc[:end]
        if frames[symbol].empty:
            raise ValueError(f"{symbol}: empty data in requested range")
    first = max(frame.index[0] for frame in frames.values())
    last = min(frame.index[-1] for frame in frames.values())
    calendars = {symbol: frame.loc[first:last].index for symbol, frame in frames.items()}
    dates = next(iter(calendars.values()))
    for calendar in calendars.values():
        dates = dates.union(calendar)
    dates = dates.sort_values()
    for symbol, calendar in calendars.items():
        missing = dates.difference(calendar)
        allowed = pd.DatetimeIndex(config.get("confirmed_no_bar", {}).get(symbol, []))
        unknown = missing.difference(allowed)
        if len(unknown):
            raise ValueError(f"{symbol}: unconfirmed missing dates {unknown.tolist()}; do not forward-fill")
    if len(dates) < config["band_window"] + config["quality_window"] + 2:
        raise ValueError("Insufficient common history for warmup and evaluation")
    panel = {field: pd.DataFrame({symbol: frame.reindex(dates)[field] for symbol, frame in frames.items()})
             for field in ["open", "close", "high", "low", "volume"]}
    panel["signal_close"] = panel["close"].copy()
    panel["tradable"] = pd.DataFrame(True, index=dates, columns=frames)
    for symbol in frames:
        missing = dates.difference(calendars[symbol])
        prior_close = panel["close"][symbol].ffill().shift(1)
        for date in missing:
            if pd.isna(prior_close.loc[date]):
                raise ValueError(f"{symbol}: no prior valuation for suspended bar")
            # Explicitly confirmed suspension: carry known value, not synthetic trading prices.
            for field in ["open", "close", "high", "low"]:
                panel[field].loc[date, symbol] = prior_close.loc[date]
            panel["volume"].loc[date, symbol] = 0.0
            panel["tradable"].loc[date, symbol] = False
        for date_str in config.get("nontradable_at_open", {}).get(symbol, []):
            date = pd.Timestamp(date_str)
            if date in dates:
                panel["tradable"].loc[date, symbol] = False
                # A 10:30 resumption price is unknown at the 09:30 rebalance.
                panel["open"].loc[date, symbol] = panel["close"][symbol].shift(1).loc[date]
    return panel
