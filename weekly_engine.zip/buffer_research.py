"""Validate no-trade bands with a weekly risk-budget override."""
import argparse
import hashlib
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

import weekly_momentum as base
from strategy import metrics
from volatility_research import audit, drawdown_details, simulate, volatility_panel

ROOT=Path(__file__).resolve().parent


def risk_metrics(daily,sizing,forecasts,target,buffer):
    # Review every common market week, including weeks in which four-week policy does not size.
    calendar=pd.Series(daily.index,index=daily.index).groupby(daily.index.to_period('W-FRI')).first()
    weekly=[]
    for date in calendar:
        row=daily.loc[date]
        if row.holding=='CASH':continue
        previous=forecasts.index[forecasts.index.get_loc(date)-1]
        sigma=forecasts.loc[previous,row.holding]
        expected=1.0 if sigma==0 else min(1.,target/sigma)
        weekly.append({'date':date,'actual_weight':row.actual_open_exposure,
                       'fresh_target_weight':expected,'estimated_risk':row.actual_open_exposure*sigma})
    measured=pd.DataFrame(weekly)
    deviation=(measured.actual_weight-measured.fresh_target_weight).abs()
    risk=measured.estimated_risk
    actual_close_risk=[]
    for date,row in daily.iterrows():
        actual_close_risk.append(row.exposure*forecasts.loc[date,row.holding] if row.holding!='CASH' else 0.0)
    actual_close_risk=pd.Series(actual_close_risk,index=daily.index)
    return {'fills':int((daily.turnover>1e-10).sum()), 'mean_weekly_weight_deviation':float(deviation.mean()),
            'max_weekly_weight_deviation':float(deviation.max()),
            'weeks_over_risk_tolerance':int((risk>target*(1+buffer)+1e-10).sum()),
            'max_weekly_estimated_risk':float(risk.max()),
            'daily_over_risk_tolerance_ratio':float((actual_close_risk>target*(1+buffer)+1e-10).mean()),
            'band_skips':int(sizing.decision_reason.eq('hold_band').sum()),
            'risk_override_count':int(sizing.decision_reason.eq('risk_excess').sum())},actual_close_risk,measured


def annual_drawdown(daily):
    rows=[]
    for y,part in daily.groupby(daily.index.year):
        previous=daily.loc[daily.index<part.index[0],'nav']
        initial=previous.iloc[-1] if len(previous) else 1.0
        dd=part.nav/part.nav.cummax().clip(lower=initial)-1
        rows.append({'year':int(y),'return':float((1+part['return']).prod()-1),
                     'max_drawdown':float(dd.min()),'average_exposure':float(part.exposure.mean())})
    return rows


def render(out,results,summary,annual,primary_sizing,costs,meta):
    labels=meta['labels']
    cols=['annual_return','max_drawdown','annual_vol','sharpe_zero_rf','average_exposure',
          'fills','mean_weekly_weight_deviation','weeks_over_risk_tolerance','year_2026_max_drawdown']
    display=summary[cols].copy()
    display.index=display.index.map(labels)
    for col in cols:
        if col not in ['sharpe_zero_rf','fills','weeks_over_risk_tolerance']:
            display[col]=display[col].map(lambda x:f'{x:.2%}')
    display.sharpe_zero_rf=display.sharpe_zero_rf.map(lambda x:f'{x:.2f}')
    display.rename(columns={'annual_return':'年化收益','max_drawdown':'最大回撤','annual_vol':'实际年化波动',
                            'sharpe_zero_rf':'夏普','average_exposure':'平均仓位','fills':'成交笔数',
                            'mean_weekly_weight_deviation':'平均周初仓位偏离','weeks_over_risk_tolerance':'周初预估风险>22%次数',
                            'year_2026_max_drawdown':'2026最大回撤'},inplace=True)
    years=annual.pivot(index='year',columns='variant',values='return')[['weekly','band5','four_week']]
    years.columns=years.columns.map(labels);years=years.apply(lambda s:s.map(lambda x:f'{x:.2%}'))
    dd=annual.pivot(index='year',columns='variant',values='max_drawdown')[['weekly','band5','four_week']]
    dd.columns=dd.columns.map(labels);dd=dd.apply(lambda s:s.map(lambda x:f'{abs(x):.2%}'))
    figs,axes=plt.subplots(3,1,figsize=(12,10),sharex=True)
    names={'weekly':'Weekly exact target','band5':'5pp band + 22% risk override','four_week':'Every 4 weeks exact target'}
    for key in names:
        f=results[key]
        axes[0].plot(f.index,f.nav,label=names[key])
        axes[1].plot(f.index,f.nav/f.nav.cummax().clip(lower=1)-1,label=names[key])
    axes[2].plot(results['band5'].index,results['band5'].exposure,label='Actual exposure: band policy')
    for ax in axes:ax.grid(alpha=.2);ax.legend(fontsize=8)
    for ax,label in zip(axes,['NAV','Drawdown','Exposure']):ax.set_ylabel(label)
    axes[2].set_ylim(0,1.05)
    figs.suptitle('Weekly monitoring, trade only beyond band or risk tolerance')
    figs.tight_layout();figs.savefig(out/'equity_drawdown.png',dpi=160);plt.close(figs)
    cs=costs.pivot(index='cost_bps',columns='variant',values='annual_return')[['weekly','band5','four_week']]
    cs.columns=cs.columns.map(labels);cs=cs.apply(lambda s:s.map(lambda x:f'{x:.2%}'))
    cs.index.name='单边成本bp'
    p,w,f=summary.loc['band5'],summary.loc['weekly'],summary.loc['four_week']
    genuine_skips=int((primary_sizing.decision_reason.eq('hold_band') & primary_sizing.asset.ne('CASH') &
                      (primary_sizing.signal_weight-primary_sizing.target_weight).abs().gt(1e-10)).sum())
    page=f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>仓位缓冲区验证</title>
<style>body{{background:#f3f5f9;color:#172033;font:15px/1.8 'Microsoft YaHei',sans-serif}}main{{max-width:1280px;margin:32px auto;padding:0 20px}}section{{background:white;border-radius:12px;padding:24px;margin:18px 0}}table{{border-collapse:collapse;white-space:nowrap;width:100%}}td,th{{padding:8px;text-align:right;border-bottom:1px solid #ddd}}th:first-child,td:first-child{{text-align:left}}.scroll{{overflow:auto}}img{{width:100%}}a{{color:#285fca}}</style>
<main><h1>四ETF：每周检查，小幅仓位变化不交易</h1><p>{summary.loc['weekly','start']}—{summary.loc['weekly','end']} · 保留20%波动目标、63日估计及原4周选ETF逻辑</p>
<section><h2>验证结果</h2><p>5个百分点缓冲区主方案年化{p['annual_return']:.2%}、最大回撤{abs(p['max_drawdown']):.2%}、成交{int(p['fills'])}笔；原每周精确调整版分别为{w['annual_return']:.2%}、{abs(w['max_drawdown']):.2%}、{int(w['fills'])}笔。成交减少{1-p['fills']/w['fills']:.2%}，年化收益变化{(p['annual_return']-w['annual_return'])*100:+.2f}个百分点，最大回撤变化{(abs(p['max_drawdown'])-abs(w['max_drawdown']))*100:+.2f}个百分点。</p>
<p>5个百分点与22%风险触发线在查看结果前固定，2.5/7.5个百分点仅作敏感性检查。不能根据回测收益最大的缓冲区替换主方案。</p>
<p>本次支持将缓冲区作为减少操作的执行改进，不支持把它描述成收益增强：主方案扣费后年化低于每周精确版，最大回撤相同，实际年化波动略高。相较每4周版，成交仍接近，但每周风险检查减少了对风险预算的偏离。</p>
<div class="scroll">{display.to_html(border=0)}</div><img src="equity_drawdown.png" alt="净值、回撤及缓冲区实际仓位"></section>
<section><h2>具体规则与信号时点</h2><ol><li>每4根有效周线按26周正动量及40周均线条件选最强ETF；规模门槛仍为滞后净资产大于10亿元。每周风险检查不重新选ETF或增加趋势退出。</li>
<li>每个有效周收盘，用当时持有单位×收盘价格和现金计算实际仓位，同时用截至该日63个真实报价收益估计年化波动。风险目标仓位=min(100%，20%÷预估波动)。</li>
<li>同一ETF目标仓位与周收盘实际仓位相差不到5个百分点时暂不调整；累计价格漂移也计入差异。差异达到5个百分点时，下一周开盘直接回到目标仓位。买入与卖出采用同一缓冲区，不增加分步加仓机制。</li>
<li>如果需要减仓且周收盘仓位×预估波动&gt;22%，即使仓位差小于5个百分点也执行减仓。换ETF、首次建仓、转为现金强制执行，不受缓冲区限制。同一赢家的4周选ETF日仍适用缓冲区。</li>
<li>判断是否交易只使用周收盘信息，不用下一周开盘决定是否触发。开盘价仅用于执行。现金收益0、无杠杆，单边费用5bp，计入仓位调整成本；无法成交则冻结。</li></ol></section>
<section><h2>风险偏离与触发次数</h2><p>主方案{int(p['band_skips'])}次周检查未触发调整（含现金期和目标未变），其中{genuine_skips}次存在非零仓位偏差但选择保持；风险超限触发{int(p['risk_override_count'])}次。调整后周初实际仓位相对目标的平均绝对偏离为{p['mean_weekly_weight_deviation']:.2%}，最大为{p['max_weekly_weight_deviation']:.2%}。周初预估风险超过22%的次数为{int(p['weeks_over_risk_tolerance'])}，最高预估值{p['max_weekly_estimated_risk']:.2%}。</p>
<p>共同每个周初检查，预估风险超过22%的次数：每周精确版{int(w['weeks_over_risk_tolerance'])}次，缓冲区主方案{int(p['weeks_over_risk_tolerance'])}次，每4周版{int(f['weeks_over_risk_tolerance'])}次。主方案最大周初偏离略超过5个百分点、预估风险略超22%，原因是触发用前一周收盘判断，下一开盘跳空后仓位发生变化。不能用开盘后的结果反向改变前一周决策。</p>
<p>所有版本均按共同的每个周初检查偏离，含每4周版未调仓的周。22%只是周收盘的预估风险触发线，既不是实际波动保证，也不是最大回撤上限。信号后开盘跳空和周内风险变化仍可能暂时超限；报告保留周初和逐日风险偏离，不能把缓冲区描述为严格风险上限。</p>
<p><a href="band5_sizing.csv">每周检查及触发原因</a> · <a href="weekly_risk_review.csv">共同周初风险检查</a> · <a href="risk_path.csv">逐日预估风险</a></p></section>
<section><h2>逐年收益</h2><div class="scroll">{years.to_html(border=0)}</div><h2>逐年最大回撤</h2><div class="scroll">{dd.to_html(border=0)}</div><p>2026为部分年度，连续核算跨年持仓。逐年回撤包含上一年末净值，不能简单平均成全期回撤。</p></section>
<section><h2>交易成本敏感性：年化收益</h2><div class="scroll">{cs.to_html(border=0)}</div><p><a href="costs.csv">各费用情景的完整风险与收益指标</a></p></section>
<section><h2>核对、复现与局限</h2><p>每周精确版与原报告逐日净值吻合，每4周版亦吻合。所有实验与原策略每天持有的ETF一致，没有新增提前退出。独立重建现金、净值、费用；用历史报价重新估计波动，逐周重算周收盘仓位及缓冲区触发，不用未来价格决定交易。</p>
<p>本研究只验证交易缓冲区，主方案与相邻阈值在已查看历史上进行机制比较，不证明未来有效。沿用公开行情、报告日后100天可用的规模近似与连续复权单位，未模拟一般涨跌停、最低佣金、100份交易单位和所有盘中停牌。</p>
<p><a href="summary.csv">全部指标</a> · <a href="annual_returns.csv">逐年收益与回撤</a> · <a href="band5_daily.csv">主方案每日净值及仓位</a> · <a href="band5_trades.csv">主方案成交</a> · <a href="metadata.json">配置与独立核对</a></p>
<p>复现：<code>python buffer_research.py --config buffer_config.json</code>。<a href="../etf_volatility/report.html">返回波动率仓位验证</a>。</p></section></main></html>'''
    (out/'report.html').write_text(page,encoding='utf8')


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--config',default='buffer_config.json')
    args=parser.parse_args();research=json.loads((ROOT/args.config).read_text(encoding='utf8'))
    cfg=json.loads((ROOT/research['base_config']).read_text(encoding='utf8'))
    if pd.Timestamp(research['end'])>pd.Timestamp(base.completed_end()):raise ValueError('Incomplete bar')
    base.DATA=ROOT/cfg['data_dir']
    panel,universe,manifest,_,_=base.load_market(cfg,research['end'])
    start=int(panel['close'].index.searchsorted(pd.Timestamp(cfg['backtest_start'])))
    full,trades,selections=base.simulate_weekly(panel,cfg,start)
    base.audit(panel,cfg,full,trades,selections)
    forecasts=volatility_panel(panel['raw_close'],research['volatility_window'],cfg['annualization'])
    out=ROOT/research['output_dir'];out.mkdir(parents=True,exist_ok=True)
    results={};audits={};labels={};summaries={};risk_path={};sizing_frames={};weekly_reviews=[]
    specifications={'weekly':({},'每周精确调整'), 'four_week':({'cadence':'four_week'},'每4周精确调整'),
                    'band5':({'band':research['primary_band'],'risk_buffer':research['risk_buffer']},'主方案：5个百分点缓冲＋风险触发'),
                    'band5_no_override':({'band':research['primary_band']},'5个百分点缓冲：无风险触发对照')}
    for band in research['band_sensitivity']:
        specifications[f'band{band*100:g}']=({'band':band,'risk_buffer':research['risk_buffer']},f'{band:.1%}仓位缓冲（敏感性）')
    for key,(options,label) in specifications.items():
        params={'target':research['target_vol'],**options}
        f,t,s=simulate(panel,cfg,start,selections,forecasts,**params)
        audits[key]=audit(panel,cfg,start,selections,f,t,s,research['volatility_window'],**params)
        assert f.holding.equals(full.holding), 'Buffer changed ETF or exit dates'
        if key in ['weekly','four_week']:
            previous=pd.read_csv(ROOT/'output/etf_volatility'/f"{'vol20' if key=='weekly' else 'vol20_four_week'}_daily.csv",parse_dates=['date']).set_index('date')
            np.testing.assert_allclose(f.nav,previous.nav,rtol=1e-12,atol=1e-12)
        extra,estimated,weekly_review=risk_metrics(f,s,forecasts,research['target_vol'],research['risk_buffer'])
        weekly_reviews.append(weekly_review.assign(variant=key))
        extra['fills']=len(t)
        summaries[key]={**metrics(f,cfg['annualization']),**drawdown_details(f),**extra}
        results[key]=f;sizing_frames[key]=s;labels[key]=label;risk_path[key]=estimated
        base.save(f,out/f'{key}_daily.csv');base.save(t,out/f'{key}_trades.csv',index=False);base.save(s,out/f'{key}_sizing.csv',index=False)
    summary=pd.DataFrame(summaries).T;summary.index.name='variant';base.save(summary,out/'summary.csv')
    annual=pd.DataFrame([{'variant':key,**row} for key,f in results.items() for row in annual_drawdown(f)])
    base.save(annual,out/'annual_returns.csv',index=False);base.save(pd.DataFrame(risk_path),out/'risk_path.csv')
    base.save(pd.concat(weekly_reviews,ignore_index=True),out/'weekly_risk_review.csv',index=False)
    base.save(selections,out/'selection_decisions.csv',index=False)
    costs=[]
    for cost in research['cost_sensitivity_bps']:
        scenario={**cfg,'commission_bps':cost,'slippage_bps':0}
        for key in ['weekly','four_week','band5']:
            params={'target':research['target_vol'],**specifications[key][0]}
            f,t,s=simulate(panel,scenario,start,selections,forecasts,**params)
            audit(panel,scenario,start,selections,f,t,s,research['volatility_window'],**params)
            costs.append({'cost_bps':cost,'variant':key,'fills':len(t),**metrics(f,cfg['annualization'])})
    costs=pd.DataFrame(costs);base.save(costs,out/'costs.csv',index=False)
    meta={'research_config':research,'base_config':cfg,'labels':labels,'audits':audits,'data_manifest':manifest,
          'price_hashes':dict(zip(universe.symbol,universe.sha256)),
          'scale_history_sha256':hashlib.sha256((base.DATA/'scale_history.csv').read_bytes()).hexdigest()}
    (out/'metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf8')
    render(out,results,summary,annual,sizing_frames['band5'],costs,meta)
    previous=ROOT/'output/etf_volatility/report.html';content=previous.read_text(encoding='utf8')
    link='<p><a href="../etf_buffer/report.html">新增验证：每周检查，小幅仓位变化不交易</a></p>'
    if '../etf_buffer/report.html' not in content:previous.write_text(content.replace('<main>','<main>'+link,1),encoding='utf8')
    print(summary[['annual_return','max_drawdown','annual_vol','sharpe_zero_rf','fills','mean_weekly_weight_deviation','weeks_over_risk_tolerance','risk_override_count']].to_string())
    print('Report:',out/'report.html')


if __name__=='__main__':main()
