"""Password-derived AES-GCM envelopes; never persist or print the password."""
import base64
import hashlib
import json
import os
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

ITERATIONS = 600_000
AAD = b'two-etf-pwa|encrypted-v1'


def b64(value):
    return base64.b64encode(value).decode('ascii')


def validate_envelope(envelope):
    if (envelope.get('format') != 'two-etf-encrypted-v1' or
            envelope.get('algorithm') != 'AES-GCM' or
            envelope.get('kdf') != 'PBKDF2-SHA256' or
            envelope.get('iterations') != ITERATIONS):
        raise ValueError('Unsupported encrypted data')
    salt = base64.b64decode(envelope['salt'], validate=True)
    iv = base64.b64decode(envelope['iv'], validate=True)
    ciphertext = base64.b64decode(envelope['ciphertext'], validate=True)
    if len(salt) != 16 or len(iv) != 12 or len(ciphertext) < 16:
        raise ValueError('Invalid encrypted data')
    return salt, iv, ciphertext


def seal(record, password, *, salt=None):
    if not password:
        raise ValueError('APP_PASSWORD is required')
    salt = salt if salt is not None else os.urandom(16)
    key = hashlib.pbkdf2_hmac('sha256', password.encode('utf8'), salt, ITERATIONS, 32)
    iv = os.urandom(12)
    plaintext = json.dumps(record, ensure_ascii=False, allow_nan=False, separators=(',', ':')).encode('utf8')
    ciphertext = AESGCM(key).encrypt(iv, plaintext, AAD)
    return dict(format='two-etf-encrypted-v1', algorithm='AES-GCM', kdf='PBKDF2-SHA256',
                iterations=ITERATIONS, salt=b64(salt), iv=b64(iv), ciphertext=b64(ciphertext))


def unseal(envelope, password):
    salt, iv, ciphertext = validate_envelope(envelope)
    key = hashlib.pbkdf2_hmac('sha256', password.encode('utf8'), salt, ITERATIONS, 32)
    return json.loads(AESGCM(key).decrypt(iv, ciphertext, AAD))


def write_sealed(path, record, password, *, salt=None):
    envelope = seal(record, password, salt=salt)
    # Authenticate our own output before replacing the last known-good envelope.
    assert unseal(envelope, password) == record
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(envelope, separators=(',', ':')), encoding='utf8')
    temporary.replace(path)
    return envelope
