"""Causal channel rotation and next-open portfolio accounting."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

VARIANTS = ("rank_only", "breakout", "width_quality")


def validate_config(config: dict) -> None:
    for key in ["band_window", "quality_window", "vol_window", "top_n", "annualization"]:
        if not isinstance(config[key], int) or config[key] < 1:
            raise ValueError(f"{key} must be a positive integer")
    if config["band_window"] < 2 or config["vol_window"] < 2:
        raise ValueError("band and volatility windows must be at least 2")
    if not 1 <= config["top_n"] <= len(config["symbols"]):
        raise ValueError("top_n outside universe")
    if config["band_multiplier"] <= 0 or config["initial_capital"] <= 0:
        raise ValueError("band multiplier and capital must be positive")
    if not 0 < config["quality_min"] <= config["quality_max"]:
        raise ValueError("Invalid quality bounds")
    if min(config["commission_bps"], config["slippage_bps"]) < 0:
        raise ValueError("Costs cannot be negative")
    if config["commission_bps"] + config["slippage_bps"] >= 10000:
        raise ValueError("Costs must be below 100%")
    if not isinstance(config.get("momentum_enabled", False), bool):
        raise ValueError("momentum_enabled must be boolean")
    window = config.get("momentum_window", 65)
    if not isinstance(window, int) or isinstance(window, bool) or window < 1:
        raise ValueError("momentum_window must be a positive integer")
    if not 0 < config.get("max_weight", 1.0) <= 1:
        raise ValueError("max_weight must be in (0, 1]")
    if config.get("rebalance_policy", "daily") not in ["daily", "membership", "weekly"]:
        raise ValueError("Unknown rebalance_policy")


def indicators(close: pd.DataFrame, config: dict) -> dict[str, pd.DataFrame]:
    if close.isna().any().any():
        # Missing values are only confirmed suspensions, validated by the loader.
        # Count observed bars per ETF, never insert a fake close into its rolling window.
        parts = {symbol: indicators(close[[symbol]].dropna(), config) for symbol in close}
        return {key: pd.DataFrame({symbol: (part[key][symbol].astype(float).reindex(close.index).ffill().fillna(0).astype(bool)
                                          if key == "rising" else part[key][symbol].reindex(close.index).ffill())
                                  for symbol, part in parts.items()})
                for key in next(iter(parts.values()))}
    middle = close.rolling(config["band_window"], min_periods=config["band_window"]).mean()
    std = close.rolling(config["band_window"], min_periods=config["band_window"]).std(ddof=0)
    upper = middle + config["band_multiplier"] * std
    lower = middle - config["band_multiplier"] * std
    spread = (upper - lower).where(upper > lower)
    position = (close - lower) / spread
    bandwidth = spread / middle
    typical = bandwidth.rolling(config["quality_window"], min_periods=config["quality_window"]).median()
    quality = np.sqrt(bandwidth / typical).clip(config["quality_min"], config["quality_max"])
    vol = close.pct_change(fill_method=None).rolling(config["vol_window"], min_periods=config["vol_window"]).std(ddof=0)
    vol = vol.where(vol > 0)
    return {"middle": middle, "upper": upper, "lower": lower,
            "position": position, "bandwidth": bandwidth, "quality": quality,
            "vol": vol, "rising": middle > middle.shift(1),
            "momentum": close.pct_change(periods=config.get("momentum_window", 65), fill_method=None)}


def candidate_positions(ind: dict[str, pd.DataFrame], row: int, config: dict) -> pd.Series:
    """Filter before ranking; nonpositive or missing momentum is ineligible."""
    position = ind["position"].iloc[row]
    if config.get("momentum_enabled", False):
        momentum = ind["momentum"].iloc[row]
        position = position.loc[np.isfinite(momentum) & (momentum > 0)]
    return position.loc[np.isfinite(position)]


def target_weights(ind: dict[str, pd.DataFrame], row: int, held: set[str],
                   config: dict, variant: str) -> pd.Series:
    if variant not in VARIANTS:
        raise ValueError(f"Unknown strategy {variant}")
    position = ind["position"].iloc[row]
    vol = ind["vol"].iloc[row]
    quality = ind["quality"].iloc[row]
    out = pd.Series(0.0, index=position.index)
    if not (np.isfinite(position).all() and np.isfinite(vol).all() and np.isfinite(quality).all()):
        return out
    # Stable tie-break follows configured symbol order.
    leaders = candidate_positions(ind, row, config).sort_values(
        ascending=False, kind="stable").index[:config["top_n"]]
    selected = []
    for symbol in leaders:
        if variant == "rank_only":
            selected.append(symbol)
        elif symbol in held and position[symbol] > 0.5:
            selected.append(symbol)
        elif symbol not in held and position[symbol] > 1 and bool(ind["rising"].iloc[row][symbol]):
            # Being outside the upper band suffices; no prior-day crossing required.
            selected.append(symbol)
    if selected:
        raw = 1.0 / vol.loc[selected]
        if variant == "width_quality":
            raw *= quality.loc[selected]
        # Any weight above the cap stays in cash; do not redistribute it.
        out.loc[selected] = (raw / raw.sum()).clip(upper=config.get("max_weight", 1.0))
    return out


def allocate(equity: float, current_values: np.ndarray, weights: np.ndarray,
             cost_rate: float) -> tuple[np.ndarray, float, float]:
    """Solve post-cost equity so buys and sells fit cash exactly."""
    if equity <= 0 or cost_rate < 0 or cost_rate >= 1:
        raise ValueError("Invalid equity or cost rate")
    if np.any(weights < 0) or weights.sum() > 1 + 1e-10:
        raise ValueError("Long-only weights must sum to at most one")
    low, high = 0.0, equity
    for _ in range(60):
        post = (low + high) / 2
        difference = post + cost_rate * np.abs(post * weights - current_values).sum() - equity
        if difference > 0:
            high = post
        else:
            low = post
    post = (low + high) / 2
    values = post * weights
    cost = cost_rate * np.abs(values - current_values).sum()
    cash = equity - cost - values.sum()
    if cash < -equity * 1e-10:
        raise ArithmeticError("Allocation overspent cash")
    return values, max(0.0, cash), cost


def allocate_with_freeze(equity: float, current_values: np.ndarray, weights: np.ndarray,
                         cost_rate: float, tradable: np.ndarray) -> tuple[np.ndarray, float, float]:
    """Keep suspended holdings fixed and rebalance with available capital only."""
    if tradable.all():
        return allocate(equity, current_values, weights, cost_rate)
    values = current_values.copy()
    locked = float(current_values[~tradable].sum())
    available = max(0.0, equity - locked)
    if available < 1e-10:
        return values, 0.0, 0.0
    selected = weights[tradable]
    desired = float(selected.sum())
    if desired > 0:
        budget = min(equity * desired, available)
        free_weights = selected / desired * budget / available
    else:
        free_weights = np.zeros_like(selected)
    values[tradable], cash, cost = allocate(available, current_values[tradable], free_weights, cost_rate)
    return values, cash, cost


@dataclass
class Result:
    daily: pd.DataFrame
    trades: pd.DataFrame
    targets: pd.DataFrame


def evaluation_start(ind: dict[str, pd.DataFrame], config: dict) -> int:
    ready = pd.Series(True, index=ind["position"].index)
    keys = ["position", "vol", "quality"]
    if config.get("momentum_enabled", False):
        keys.append("momentum")
    for key in keys:
        ready &= np.isfinite(ind[key]).all(axis=1)
    candidates = np.flatnonzero(ready.to_numpy())
    if not len(candidates):
        raise ValueError("Indicators never become valid")
    # Warmup closes in cash; first signal can only execute at following open.
    requested = ind["position"].index.searchsorted(pd.Timestamp(config["backtest_start"]))
    start = max(int(candidates[0]) + 1, int(requested))
    if start >= len(ready):
        raise ValueError("No dates after warmup/backtest_start")
    return start


def simulate(panel: dict[str, pd.DataFrame], ind: dict[str, pd.DataFrame],
             config: dict, variant: str, start: int) -> Result:
    opens, closes = panel["open"], panel["close"]
    symbols = opens.columns
    capital = float(config["initial_capital"])
    cash, previous_close_equity = capital, capital
    units = np.zeros(len(symbols))
    cost_rate = (config["commission_bps"] + config["slippage_bps"]) / 10000
    targets, daily, trades = [], [], []
    for row in range(start, len(opens)):
        date, signal_date = opens.index[row], opens.index[row - 1]
        held = set(symbols[units > 1e-12])
        if variant == "equal_weight":
            weights = pd.Series(1 / len(symbols), index=symbols)
        elif variant == "buy_hold_300":
            weights = pd.Series(0.0, index=symbols)
            weights.loc["sh510300" if "sh510300" in symbols else symbols[0]] = 1.0
        else:
            weights = target_weights(ind, row - 1, held, config, variant)
        # Benchmark 300 buys once; equal_weight rebalances every open.
        if variant == "buy_hold_300" and row > start:
            values = units * opens.iloc[row].to_numpy()
            equity_open, fee, turnover = cash + values.sum(), 0.0, 0.0
        else:
            before = units * opens.iloc[row].to_numpy()
            equity_open = cash + before.sum()
            tradable = (panel["tradable"].iloc[row].to_numpy(dtype=bool)
                        if "tradable" in panel else np.ones(len(symbols), dtype=bool))
            policy = config.get("rebalance_policy", "daily") if variant in VARIANTS else "daily"
            if policy == "weekly":
                scheduled = row == start or date.to_period("W") != opens.index[row - 1].to_period("W")
            elif policy == "membership":
                scheduled = not np.array_equal(units > 1e-12, weights.to_numpy() > 0)
            else:
                scheduled = True
            if scheduled:
                values, cash, fee = allocate_with_freeze(equity_open, before, weights.to_numpy(), cost_rate, tradable)
            else:
                # Between weekly entries/rebalances, exits remain daily.
                # Unchanged holdings keep units, rather than resetting weights after costs.
                exits = (weights.to_numpy() <= 0) & (units > 1e-12) & tradable
                values = before.copy()
                proceeds = float(values[exits].sum())
                fee = proceeds * cost_rate
                cash += proceeds - fee
                values[exits] = 0
            changes = values - before
            turnover = np.abs(changes).sum() / equity_open
            units = values / opens.iloc[row].to_numpy()
            for col, symbol in enumerate(symbols):
                if abs(changes[col]) > 1e-6:
                    trades.append({"date": date, "signal_date": signal_date, "symbol": symbol,
                                   "side": "BUY" if changes[col] > 0 else "SELL",
                                   "notional": abs(changes[col]), "cost": abs(changes[col]) * cost_rate,
                                   "adjusted_open": opens.iloc[row, col],
                                   "adjusted_units_delta": changes[col] / opens.iloc[row, col]})
        close_values = units * closes.iloc[row].to_numpy()
        equity = cash + close_values.sum()
        daily.append({"date": date, "equity": equity, "nav": equity / capital,
                      "return": equity / previous_close_equity - 1,
                      "equity_at_open_before_cost": equity_open,
                      "cash": cash, "cash_weight": cash / equity,
                      "exposure": close_values.sum() / equity, "cost": fee, "turnover": turnover,
                      **{f"weight_{symbol}": close_values[col] / equity for col, symbol in enumerate(symbols)}})
        targets.append({"date": date, "signal_date": signal_date, **weights.to_dict()})
        previous_close_equity = equity
    daily_frame = pd.DataFrame(daily).set_index("date")
    trade_frame = pd.DataFrame(trades, columns=["date", "signal_date", "symbol", "side", "notional",
                                               "cost", "adjusted_open", "adjusted_units_delta"])
    return Result(daily_frame, trade_frame, pd.DataFrame(targets).set_index("date"))


def metrics(daily: pd.DataFrame, annualization: int) -> dict:
    returns = daily["return"]
    nav = (1 + returns).cumprod()
    peak = nav.cummax().clip(lower=1)
    n = len(returns)
    annual_return = float(nav.iloc[-1] ** (annualization / n) - 1)
    annual_vol = float(returns.std(ddof=0) * np.sqrt(annualization))
    mean_return = float(returns.mean())
    vol = float(returns.std(ddof=0))
    return {"start": str(daily.index[0].date()), "end": str(daily.index[-1].date()), "days": n,
            "total_return": float(nav.iloc[-1] - 1), "annual_return": annual_return,
            "annual_vol": annual_vol,
            "sharpe_zero_rf": mean_return / vol * np.sqrt(annualization) if vol > 0 else None,
            "max_drawdown": float((nav / peak - 1).min()),
            "positive_day_ratio": float((returns > 0).mean()),
            "average_exposure": float(daily["exposure"].mean()),
            "cash_day_ratio": float((daily["exposure"] < 1e-10).mean()),
            "annual_traded_notional_over_nav": float(daily["turnover"].mean() * annualization),
            "total_cost": float(daily["cost"].sum())}
